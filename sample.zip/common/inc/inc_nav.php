<header id="header" class="header">
<div class="header-wrap">
 <nav class="row" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="/index.php" class="brand-logo center"><img src="../../common/images/logo1.png"  alt="중문색달마을"/></a>
      <ul class="tabs tabs-transparent hide-on-med-and-down">
        <li class="col s2"><a href="/user/town/town_01.php">중문색달마을</a></li>
         <li class="col s2"><a href="/user/park/park_01.php">생수천 생태문화공원</a></li>
           <li class="col s2"><a href="/user/natural/natural_01.php">색달동 자원</a></li>
            <li class="col s2"><a href="/user/board/noticeBoard.php">커뮤니티</a></li>
             <li class="col s2"><a href="/user/site/sitemap.php">사이트맵/관리자</a></li>
      </ul>

      <ul id="nav-mobile" class="side-nav">
        <li><a href="/user/town/town_01.php">중문색달마을</a></li>
         <li><a href="/user/park/park_01.php">생수천 생태문화공원</a></li>
           <li><a href="/user/natural/natural_01.php">색달동 자원</a></li>
            <li><a href="/user/board/noticeBoard.php">커뮤니티</a></li>
             <li><a href="/user/site/sitemap.php">사이트맵/관리자</a></li>
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
  </nav>
 </div> 
 </header>