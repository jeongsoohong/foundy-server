<? @session_start();?>
<footer class="page-footer">
    <div class="container center-align">
   		<!-- <a href="/user/site/privacy.php" class="btn btn_foot grey darken-4">개인정보취급방침</a> | --> 
   		<a href="/user/site/sitemap.php" class="btn">사이트맵</a>
   		
   	<? if(isset($_SESSION['ss_id'])){?>
		<a href="/admin/login/logout.php" class="btn">관리자 로그아웃</a>
	<? } else{ ?> 
		<a href="/admin/login/login.php" class="btn">관리자 로그인</a>	
	<? }?>
     </div>
      
    <div class="footer-copyright">
      <div class="container center">
   		   제주특별자치도 서귀포시 색달로81번길 53 우) 63534 | Tel. 064-738-9360 Copyrightⓒ 중문색달마을 All right reserved
       </div>
    </div>
</footer>

