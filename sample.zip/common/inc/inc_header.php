<?
//include_once "../common/config/dbconn.php"
		include_once("{$_SERVER[DOCUMENT_ROOT]}/common/config/dbconn.php"); 
?>
<script  src="http://code.jquery.com/jquery-latest.min.js"></script>
<script type="text/javascript" src="/common/js/init.js"></script>
<script type="text/javascript" src="/common/js/materialize.js"></script>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/common/css/materialize.css">
<link rel="stylesheet" type="text/css" href="/common/css/style.css">
<link rel="stylesheet" type="text/css" href="/common/css/main.css">
