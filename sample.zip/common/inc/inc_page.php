<div class="row center mt10">
   <ul class="pagination">
<?
	$total_page = ceil($query_number / $num_per_page);
	$total_block = ceil($total_page / $num_per_block);
	$block = ceil($page / $num_per_block);
	
	//첫번째 페이지
	$first_page = ($block - 1) * $num_per_block;
	
	//마지막 페이지
	$last_page = $block * $num_per_block;
	
	//이전페이지
	$prev_page = $first_page;
	
	//다음 페이지
	$next_page = $last_page + 1;
	
	//직접 페이지
	$go_page = $first_page + 1;
	
	if($total_block <= $block){
		$last_page=$total_page;
	}
	//이전 페이지
	if($block > 1){
?>
	               <li class="disabled"><a href="<?=$this_url?>?page=<?=$prev_page?><?=$add_url?>"><i class="material-icons">chevron_left</i></a></li>          
<?
	}
	//직접이동 페이지
	for($go_page; $go_page <= $last_page; $go_page++){
		if($page == $go_page){
?>
                   <li class="active"><a><?=$go_page?></a></li>
<?
		}else{ 
?>
				   <li class="waves-effect"><a href="<?=$this_url?>?page=<?=$go_page?><?=$add_url?>"><?=$go_page?></a></li>
<?
		}
	}
	//다음 페이지
	if($block < $total_block){
?>
                   <li class="waves-effect"><a href="<?=$this_url?>?page=<?=$next_page?><?=$add_url?>"><i class="material-icons">chevron_right</i></a></li>
<?
	}
?>
   </ul>
</div>