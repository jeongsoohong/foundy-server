                            <div class="col s12">   
                               <form action="<?=$this_url?>" method="get" name="search">
                               <input type="hidden" name="gubun" value="<?=$gubun?>">
                               			<div class="input-field col s1">
		                       				<select name="key" id="select" >
			                        			<option value="subject" <?if($key=="subject" || $key=="") echo "selected"; ?>>제목</option>
			                                    <option value="contents" <?if($key=="contents") echo "selected"; ?>>내용</option>
			                                    <option value="writer" <?if($key=="writer") echo "selected"; ?>>작성자</option>
			                        		</select>
			                        	</div>
			                        	<div class="col s3">
				                        	 <div class="input-field_s">
				                        		<input id="search1" type="search" name="searchword"  placeholder="검색어를 입력하세요." size="20" maxlength="30" value="<?=$searchword?>" itemname="검색어">
				                        		<label for="search1"><i class="material-icons">search</i></label>
				                        		<i class="material-icons pt10">&#xE5CD;</i>
				                        	</div>	
                				   		</div>
                				   		<div class="col s1"><button type="submit" class="waves-effect waves-light btn grey darken-1 mt25">SEARCH</button>
										</div>
                				</form>
                			</div>