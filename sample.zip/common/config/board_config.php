<?
//게시판별 설정
switch($code){
	case "tbl_notice":
		$isLogin = true;
		$isNoRobot = true;
		$isNick = false;
		$board_date = "2011-12-01";
		break;
	case "tbl_freeboard":
		$isLogin = true;
		$isNoRobot = true;
		$isNick = true;
		$board_date = "2011-12-01";
		break;
/* 	case "tbl_faq":
		$isLogin = true;
		$isNoRobot = true;
		$isNick = false;
		$board_date = "";
		break;
	case "tbl_hongbo":
		$isLogin = true;
		$isNoRobot = true;
		$isNick = false;
		$board_date = "";
		break;
	case "tbl_experience":
		$isLogin = true;
		$isNoRobot = true;
		$isNick = true;
		$board_date = "";
		break;
	default:
		$isLogin = false;
		$isNoRobot = false;
		$isNick = false;
		$board_date = "";
		break; */
}
?>