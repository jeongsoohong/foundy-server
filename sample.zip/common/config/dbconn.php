<?
//session_start();

extract($_POST);
extract($_GET);
extract($_REQUEST);

//DB연결 환경설정부분
/* $LOCAL = "192.168.0.238";
$USERDB = "16c_sdhp";
$USERID = "root";
$USERPASSWD = "Mkdo7860!"; */

//운영
$LOCAL = "localhost";
$USERDB = "saekdal";
$USERID = "saekdal";
$USERPASSWD = "sd7389360!";

//쿠키값
$COOKIE_PATH = "/";

//세션 저장 경로
$SESSION_PATH = "/tmp";

//도메인 정보
$Cookie_http = $HTTP_HOST;
$Cookie_host = ".".$Cookie_http;

$today = date("Y-m-d");

$DOCUMENT_ROOT = $_SERVER["DOCUMENT_ROOT"];
//lib파일 include

include_once $DOCUMENT_ROOT."/common/lib/sql.lib.php";
include_once $DOCUMENT_ROOT."/common/lib/string.lib.php";
include_once $DOCUMENT_ROOT."/common/lib/time.lib.php";
include_once $DOCUMENT_ROOT."/common/lib/marathon.lib.php";
include_once $DOCUMENT_ROOT."/common/lib/common.lib.php";

//DB연결 부분

$dbconn = mysql_connect($LOCAL,$USERID,$USERPASSWD) || die("DB연결이 실패하였습니다.<br>");
$select_db = mysql_select_db($USERDB);
if(!$select_db){
    $errno = mysql_errno($dbconn);
    $error = mysql_error($dbconn);
    
    echo("에러코드 --> $errno<br>");
    echo("에러메세지 --> $error<br>");
    exit;
}

$db = new mysql($LOCAL, $USERID, $USERPASSWD, $USERDB);
$db->con();

?>