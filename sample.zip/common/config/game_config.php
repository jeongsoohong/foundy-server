<?
//마라톤 일정
$game_inning 			= "14";
$game_schedule_date 		= "2016년 3월 27일(일) 09:00 출발";
$game_schedule_area 		= "한림 종합운동장";
$game_title 				= "제주MBC 국제평화마라톤";
$home_title 				= "평화! 희망! 세계로 달린다! ".$game_title;
$from_entry_title			= "제주MBC 마라톤사무국 귀하";
$from_entry_title2 			= "제주문화방송주식회사 대표이사 사장 귀하";
$full_couse_money 		= "40000";			//풀코스 참가비
$half_couse_money 		= "30000";			//하프코스 참가비
$public_couse_money 		= "25000";			//일반코스 참가비
$health_couse_money 		= "20000";			//건강코스 참가비
$health_couse_money2		= "10000";			//건강코스 참가비(학생-초중)

$full_two_couse_money		= "25000";			//풀코스 2인 1조 이어달리기 참가비
$full_couple_couse_money	= "30000";			//부부대항 풀코스 참가비

$target_gamecode 		= "20170326";           // DB에 들어가는 회차정보(14회)
$dday_gamecode 			= "20170326";			// 디데이 계산
$endEntryDate 			= "20170224235959";     // 참가신청서 받는 기간(이 기간 이후로는 신청기간이 아니다)

$jumin_check 			= "050101";
?>