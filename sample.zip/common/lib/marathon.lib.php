<?
//마라톤 코스별 금액
function getCourseMoney($course,$kind=""){
	
	global $full_couse_money, $half_couse_money, $public_couse_money, $health_couse_money, $full_two_couse_money, $full_couple_couse_money, $health_couse_money2;
	
	switch($course){
		case "풀코스":
			$money = intVal($full_couse_money);
			break;
		case "하프코스":
			$money = intVal($half_couse_money);
			break;
		case "일반코스":
			$money = intVal($public_couse_money);
			break;
		case "건강코스":
			$money = intVal($health_couse_money);
			break;
		case "풀코스2인1조이어달리기":
			$money = intVal($full_two_couse_money);
			break;
		case "부부대항풀코스":
			$money = intVal($full_couple_couse_money);
			break;
		case "부부대항풀코스":
			$money = intVal($full_couple_couse_money);
			break;
		case "건강코스-학생":
			$money = intVal($health_couse_money2);
			break;
		default:
			if($kind=="form"){
				echo "<script language=javascript>alert('코스를 선택하십시오.'); history.back(); </script>";
				exit();
			}
			break;
	}
	return $money;
}

//마라톤 신청하기 주민번호 조회
function check_jumin($game_code,$target){
	$query = "select uid from tbl_group_detail where game_code like '%".$game_code."%' and jumin in('".$target."') and delete_key <> 'N'";
	$query =  mysql_query($query);
	java_mysql_error_mesg();
	$group_chk = mysql_num_rows($query);
	
	$query = "select uid from tbl_jeju where game_code like '%".$game_code."%' and jumin in('".$target."') and delete_key <> 'N'";
	$query =  mysql_query($query);
	java_mysql_error_mesg();
	$group_chk += mysql_num_rows($query);
	
	return $group_chk;
}

//마라톤 신청하기 주민번호 조회, 단체 temp값 비교 추가
function check_jumin_temp($game_code,$target,$no){
	$query = "select uid from tbl_group_detail where game_code like '%".$game_code."%' and jumin in('".$target."') and delete_key <> 'N'";
	$query =  mysql_query($query);
	java_mysql_error_mesg();
	$group_chk = mysql_num_rows($query);
	
	//단체 temp
	$query = "select uid from tbl_group_detail_temp where game_code like '%".$game_code."%' and jumin in('".$target."') and puid='" . $no . "'";
	$query =  mysql_query($query);
	java_mysql_error_mesg();
	$group_chk += mysql_num_rows($query);
	
	$query = "select uid from tbl_jeju where game_code like '%".$game_code."%' and jumin in('".$target."') and delete_key <> 'N'";
	$query =  mysql_query($query);
	java_mysql_error_mesg();
	$group_chk += mysql_num_rows($query);
	
	return $group_chk;
}
?>