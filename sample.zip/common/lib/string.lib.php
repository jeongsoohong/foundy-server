<?
//==============================================================================
//  문자열 관련 함수
//==============================================================================


// 한글 한글자(2byte)는 길이 2, 공란.영숫자.특수문자는 길이 1
function cut_str($str, $len, $suffix="…")
{
    $s = substr($str, 0, $len);
    $cnt = 0;
    for ($i=0; $i<strlen($s); $i++)
        if (ord($s[$i]) > 127)
            $cnt++;
    $s = substr($s, 0, $len - ($cnt % 2));
    if (strlen($s) >= strlen($str))
        $suffix = "";
    return $s . $suffix;
}


// PHP 4.3.0 이전 사용자는 이렇게 할 수 있습니다:
function unhtmlentities($string)
{
   $trans_tbl = get_html_translation_table(HTML_ENTITIES);
   $trans_tbl = array_flip($trans_tbl);
   return strtr($string, $trans_tbl);
}

// TEXT 형식으로 변환
function get_text($str, $html=0)
{
    /* 3.22 막음 (HTML 체크 줄바꿈시 출력 오류때문)
    $source[] = "/  /";
    $target[] = " &nbsp;";
    */

    // 3.31
    // TEXT 출력일 경우 &amp; &nbsp; 등의 코드를 정상으로 출력해 주기 위함
    if ($html == 0) {
        $str = html_symbol($str);
    }

    $source[] = "/</";
    $target[] = "&lt;";
    $source[] = "/>/";
    $target[] = "&gt;";
    //$source[] = "/\"/";
    //$target[] = "&#034;";
    $source[] = "/\'/";
    $target[] = "&#039;";
    $source[] = "/}/";
    $target[] = "&#125;";
    if ($html) {
        $source[] = "/\n/";
        $target[] = "<br/>";
    }

    return preg_replace($source, $target, $str);
}


// way.co.kr 의 wayboard 참고
function urlautolink($str)
{
    global $default;

    /*
    $str = ereg_replace("&lt;", "\t_lt_\t", $str);
    $str = ereg_replace("&gt;", "\t_gt_\t", $str);
    $str = ereg_replace("&amp;", "&", $str);
    $str = ereg_replace("&quot;", "\"", $str);
    $str = eregi_replace("([^(http://)]|\(|^)(www\.[a-zA-Z0-9\.-]+\.[\xA1-\xFEa-zA-Z0-9\.:&#=_\?/~\+%@;-]+)", "\\1<A HREF=\"http://\\2\" TARGET='$default[de_link_target]'>\\2</A>", $str);
    $str = eregi_replace("([^(HREF=\"?'?)|(SRC=\"?'?)]|\(|^)((http|https|ftp|telnet|news|mms)://[a-zA-Z0-9\.-]+\.[\xA1-\xFEa-zA-Z0-9\.:&#=_\?/~\+%@;-\|]+)", "\\1<A HREF=\"\\2\" TARGET='$default[de_link_target]'>\\2</A>", $str);
    //$str = eregi_replace("([^(HREF=)]|\(|^)\"?'?([a-zA-Z0-9\._-]+@[a-zA-Z0-9\.-]+)", "\\1<A HREF=\"mailto:\\2\">\\2</A>", $str);
    $str = eregi_replace("(([a-z0-9_]|\-|\.)+@([^[:space:]]*)([[:alnum:]-]))", "<a href='mailto:\\1'>\\1</a>", $str); 
    $str = ereg_replace("\t_lt_\t", "&lt;", $str);
    $str = ereg_replace("\t_gt_\t", "&gt;", $str);
    */

    # 속도 향샹 031011
    $str = preg_replace("/&lt;/", "\t_lt_\t", $str);
    $str = preg_replace("/&gt;/", "\t_gt_\t", $str);
    $str = preg_replace("/&amp;/", "&", $str);
    $str = preg_replace("/&quot;/", "\"", $str);
    $str = preg_replace("/([^(http:\/\/)]|\(|^)(www\.[a-zA-Z0-9\.-]+\.[\xA1-\xFEa-zA-Z0-9\.:&#=_\?\/~\+%@;\-]+)/i", "\\1<A HREF=\"http://\\2\" TARGET='$default[de_link_target]'>\\2</A>", $str);
    $str = preg_replace("/([^(HREF=\"?'?)|(SRC=\"?'?)]|\(|^)((http|https|ftp|telnet|news|mms):\/\/[a-zA-Z0-9\.-]+\.[\xA1-\xFEa-zA-Z0-9\.:&#=_\?\/~\+%@;\-\|\,]+)/i", "\\1<A HREF=\"\\2\" TARGET='$default[de_link_target]'>\\2</A>", $str);
    $str = preg_replace("/(([a-z0-9_]|\-|\.)+@([^[:space:]]*)([[:alnum:]-]))/i", "<a href='mailto:\\1'>\\1</a>", $str); 
    $str = preg_replace("/\t_lt_\t/", "&lt;", $str);
    $str = preg_replace("/\t_gt_\t/", "&gt;", $str);

    return $str;
}


// url에 http:// 를 붙인다
function set_http($url)
{
    if (!trim($url)) return;

    // 3.32
    //if (!eregi("^(http|https)://", $url))
    if (!eregi("^(http|https|ftp|telnet|news|mms)://", $url))
        $url = "http://" . $url;

    return $url;
}


// HTML 특수문자 변환 htmlspecialchars
function hsc($str) 
{
    $trans = array("\"" => "&#034;", "'" => "&#039;", "<"=>"&#060;", ">"=>"&#062;");
    $str = strtr($str, $trans);
    return $str;
}

// 3.31 
// HTML SYMBOL 변환
// &nbsp; &amp; &middot; 등을 정상으로 출력
function html_symbol($str)
{
    return preg_replace("/\&([a-z0-9]{1,20}|\#[0-9]{0,3});/i", "&#038;\\1;", $str);
}


/*
* 예제1: echo kstrcut("하하하 나는 잘났어요-_-;;", 19);
* 결과1: 하하하 나는 잘났어

* 예제2: echo kstrcut("하하하 나는 잘났어요-_-;;", 20, "~!~~!");
* 결과2: 하하하 나는 잘났어요~!~~!
*/
function kstrcut($str, $len, $suffix = "") 
{
	if ($len >= strlen($str)) return $str;

	$klen = $len - 1;

	while(ord($str[$klen]) & 0x80) $klen--;

	return substr($str, 0, $len - (($len + $klen + 1) % 2)) . $suffix;
}


//해당 데이터의 특수문자를 빼고 데이터를 다 붙여서 반환
function getDataSignMinusString($target,$sign){
	$result = str_replace($sign,"",$target);
	return $result;
}

//해당 문자가 1이면 YES, 0이면 NO
function getOneAndZeroWordConvertString($target){
	$target = strVal($target);
	switch($target){
		case "0";
			$target = "NO";
			break;
		case "1":
			$target = "YES";
			break;
	}
	return $target;
}

//내용이 비었는지 검사
 function check_existence($target){
	if(!$target or empty($target) or trim($target) == "" ){
		return false;
	}else{
		return true;
	}	
 }

 //내용이 비었는지 검사후 비었으면 공백 삽입
function getNullNbspChange($target){
	if(!$target or empty($target) or trim($target) == "" ){
		return " ";
	}else{
		return $target;
	}	
 }


//숫자가 10보다 작은경우 0을 붙이고 String 형태로 바꿈
function getNumerStringZero($target){
	if(intVal($target) < 10){
		return '0'.$target;
	}else{
		return $target;
	}
}

?>
