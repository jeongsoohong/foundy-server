<?
# mysql 에러 발생시 에러 출력
function java_mysql_error_mesg() {
    if(mysql_errno()) {
		$mysql_error = mysql_error();
		$mysql_error = strtr($mysql_error,"\n","\\n");
        echo "
            <script>
			var str = \"MySQL ERROR: " . mysql_errno() . " " . $mysql_error . "\\n 디비 에러 입니다. 관리자에게 문의 해 주십시오.\"
            window.alert(str)
            history.go(-1)
            </script>";
        exit;
    }
}


//기간 부분
function Period($useday){ 
	$Today_date = date("Y-m-d"); 
	$End_day = explode("-", $useday); 
	$Today = explode("-", $Today_date); 
	$Use_day = mktime(0, 0, 0, $End_day[1], $End_day[2], $End_day[0]) - mktime(0, 0, 0, $Today[1], $Today[2], $Today[0]); 
	$Use_day = floor($Use_day / (24*60*60)); 
	return($Use_day); 
}


//카운터
function cntInsert( $ip ){
         mysql_query("INSERT into tbl_counter (ip, time) values (\"$ip\", NOW())");

}


// 필터링
function check_filter($content)
{
    $filter = "씨발,니기미,신용카드,섹스,창녀,좆까,8억,폰팅,카섹,엽기,야한,무료,금융,대출,연체,sex,무삭제,신용,오빠,음경,광고,미수금,후불,금리,카드,정액,빠구리,패티쉬,몰카,욕정,정력,회춘,씹탱구리,야동,오입질,로리타,영계,누드,자위,페니스,최저가,채팅,SEX,섹시한,섹시녀,이본,이제은,치어리더,초저가,화상,마케팅,산지직송,가격파괴,섹쉬,섹시,신상품,창업,이월상품,노마진,사업성공,세일,노출,파격,충격,치마속,변태,윤락,출장,마사지,처녀,삭제시 비밀번호,등록거부,고소득,클릭하세요,수수료,채권추심,채무상환,채무자,급전,초강력,해결하세요,삭제번호,감상하기,감상하세요,동영상,스타킹,팬티,가맹점,전문기업,자유이용권,성인게시판,대행해,성인만,야한게시판,야합니다";

    $is_bad = false;
    $pattern = explode(",", $filter);
    for ($i=0; $i<count($pattern); $i++) {
        $pattern[$i] = trim($pattern[$i]);
        if ($pattern[$i] == "") {
            continue;
        }
        $pat = "/{$pattern[$i]}/i";
        $is_bad = @preg_match($pat, $content);
        if ($is_bad) {
            break;
        }
    }

    return $is_bad;
}

// 테그가 되지 않도록 변환
function conv_content($content)
{
	// 공백 처리
	$content = str_replace("  ", "&nbsp; ", $content);
	
	//테그 처리
	$content = str_replace("<", "&lt; ", $content);
	$content = str_replace(">", "&gt; ", $content);
	return $content;
}

// 내용을 변환
function conv_content2($content, $html)
{
    if ($html)
    {
        $source = array();
        $target = array();
        
        $source[] = "//";
        $target[] = "";
        
        if ($html == 2) { // 자동 줄바꿈
            $source[] = "/\n/";
            $target[] = "<br/>";
        }else{
		$content = str_replace("&lt;", "<", $content);
		$content = str_replace("&gt;", ">", $content);
		$content = str_replace("&amp;", "&", $content);
        }
        
        // 테이블 태그의 갯수를 세어 테이블이 깨지지 않도록 한다.
        $table_begin_count = substr_count(strtolower($content), "<table");
        $table_end_count = substr_count(strtolower($content), "</table");
        
        for ($i=$table_end_count; $i<$table_begin_count; $i++)
        {
            $content .= "</table>";
        }
	
        $content = preg_replace($source, $target, $content);
	
        // XSS (Cross Site Script) 막기
        // 완벽한 XSS 방지는 없다.
        $content = preg_replace("/(on)([a-z]+)([^a-z]*)(\=)/i", "&#111;&#110;$2$3$4", $content);
        $content = preg_replace("/(dy)(nsrc)/i", "&#100;&#121;$2", $content);
        $content = preg_replace("/(lo)(wsrc)/i", "&#108;&#111;$2", $content);
        $content = preg_replace("/(sc)(ript)/i", "&#115;&#99;$2", $content);
        $content = preg_replace("/(ex)(pression)/i", "&#101&#120;$2", $content);
    }
    else // text 이면
    {
    }
    return $content;
}

//특수문자가 나타나지 안토록 빼버림
function getMarkBlankConvert($target){
	$target = str_replace("\\","",$target);
	$target = str_replace(".","",$target);
	$target = str_replace(",","",$target);
	$target = str_replace("`","",$target);
	$target = str_replace("'","",$target);
	return $target;
}

// 경고메세지를 경고창으로
function alert($msg, $url='')
{
    if (!$msg) $msg = "올바른 방법으로 이용해 주십시오.";
    echo "<script language='javascript'>alert('$msg');";
    if (!$url)
        echo "history.go(-1);";
    echo "</script>";
    if ($url)
        echo "<meta http-equiv='refresh' content='0;url=$url'>";
    exit;
}

function right($value, $count){
	$value = substr($value, (strlen($value) - $count), strlen($value));
	return $value;
}

function left($string, $count){
	return substr($string, 0, $count);
}

function getDday($tgdate) {
	$y 		= substr($tgdate, 0, 4);
	$m 		= substr($tgdate, 4, 2);
	$d 		= substr($tgdate, 6, 2);
	$now 	= time(); 
	$dday 	= mktime(0,0,0,$m,$d,$y);
	
	if($now < $dday)
		$xday 	= ceil(($dday-$now)/(60*60*24)); 
	else
		$xday = 0;
	
	//echo $xday;
	/* if($xday >= 0){
		$xday = right("000".$xday, 3);
		$arr_xday = preg_split("//",trim($xday),-1,PREG_SPLIT_NO_EMPTY);  //숫자 하나씩 자름
		for($i=0;$i<count($arr_xday);$i++) {   //자른 숫자에 해당하는 그림표현
			$result .= "<li><img src=\"/images/main/count" .$arr_xday[$i]. ".gif\" alt=\"D-" .$xday. "\" /></li>";
		}
	}else{
		for($i=0;$i<3;$i++) {   //자른 숫자에 해당하는 그림표현
			$result .= "<li><img src=\"/images/main/count0.gif\" alt=\"D-000\" /></li>";
		}
	}
	 */
	return $xday;
}
?>
