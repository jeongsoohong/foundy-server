<?
//==============================================================================
//  날짜, 시간 관련 함수
//==============================================================================


// 마이크로 타임을 얻어 계산 형식으로 만듦
function get_microtime()
{
    list($usec, $sec) = explode(" ",microtime());
    return ((float)$usec + (float)$sec);
}

//기준월의 1일 요일 알아내는 함수
function getMonthFirstDayWeekName($year,$month){
	return date("w", mktime(0,0,0, $month,01,$year));
}

//기준월의 마지막일을 알아내는 함수
function getMonthLastDayName($year,$month){
	return date("t",mktime(0,0,0,$month,1,$year));
}

//기준월 마지막일 요일 알아내는 함수
function getMonthLastDayWeekName($year,$month){
	$lastDay = getMonthLastDayName($year,$month);
	return date("w", mktime(0,0,0, $month,$lastDay,$year));
}

//두 날짜 사이의 차를 알아내기
function getDiffDateToDateInt($date1, $date2, $sign='-'){
	$date1Array = explode($sign, $date1);
	$date2Array = explode($sign, $date2);
	$y1 = $date1Array[0];
	$m1 = $date1Array[1];
	$d1 = $date1Array[2];

	$y2 = $date2Array[0];
	$m2 = $date2Array[1];
	$d2 = $date2Array[2];

	$tdiff1 = mktime(0,0,0,$m1,$d1,$y1);
	$tdiff2 = mktime(0,0,0,$m2,$d2,$y2);

	$diffTime = abs($tdiff1 - $tdiff2);

	$diffDay = intVal($diffTime/(60*60*24));

	return $diffDay;

}

//초 기준으로 된 두 날짜 사이의 차 알아내서 날짜로 반환
function getDiffTimeToDayInt($tdiff1, $tdiff2){
	
	$diffTime = abs($tdiff1 - $tdiff2);

	$diffDay = intVal($diffTime/(60*60*24));

	return $diffDay;

}

//A날짜가 B날짜보다 작은지 알아내기
function getDiffDateSmallBoolean($date1, $date2, $sign='-'){
	$date1Array = explode($sign, $date1);
	$date2Array = explode($sign, $date2);
	$y1 = $date1Array[0];
	$m1 = $date1Array[1];
	$d1 = $date1Array[2];

	$y2 = $date2Array[0];
	$m2 = $date2Array[1];
	$d2 = $date2Array[2];

	$tdiff1 = mktime(0,0,0,$m1,$d1,$y1);
	$tdiff2 = mktime(0,0,0,$m2,$d2,$y2);

	$diffTime = $tdiff1 - $tdiff2;

	$diffDay = intVal($diffTime/(60*60*24));

	if($diffDay < 0){
		return true;
	}else{
		return false;
	}
}

//기준월 원하는 요일, 원하는 주에 맞는 날짜 반환
function getMonthWeekDay($year,$month,$week,$num){
	
	$st_day = date("Y-m-d",strtotime($week,mktime(0,0,0,$month,01,$year)));
	$tarday = substr($st_day,8,2);
	
	$tarnum = ($num-1)*7;
	$st_day = date("Y-m-d",mktime (0,0,0,$month,$tarday+$tarnum,$year));
	
	return $st_day;
}


//기준월 원하는 요일에 해당하는 첫째주,둘째주,셋째주,넷째주 일자 알아내서 배열로 반환
function getMonthWeekDayArray($year,$month,$week,$extra=""){
	
	$st_day[1] = date("Y-m-d",strtotime($week,mktime(0,0,0,$month,01,$year)));
	$tarday = substr($st_day[1],8,2);
	$tarnum = 1;
	$snum = 2;
	
	if($extra =='Y'){
		$snum = 1;
	}

	for($i=$snum; $i<=4;$i++){
		$tarnum = ($i-1)*7;
		if($extra =='Y'){
			$tarnum = $i * 7;
		}
		$st_day[$i] = date("Y-m-d",mktime (0,0,0,$month,$tarday+$tarnum,$year));
	}

	return $st_day;
}

//날짜에서 년,월,일 추출
function getyyyymmdd($target,$kind){
	switch($kind){
		case "y":
			return substr($target,0,4);
			break;
		case "m":
			return substr($target,5,2);
			break;
		case "d":
			return substr($target,8,2);
			break;
		
	}
}

//기준일로부터 해당일자 날짜별로 숫자로 변환
function getDateNumDayChange($target,$sdate){
	$ty = getyyyymmdd($target,'y');
	$tm = getyyyymmdd($target,'m');
	$td = getyyyymmdd($target,'d');
	$sy = getyyyymmdd($sdate,'y');
	$sm = getyyyymmdd($sdate,'m');
	$sd = getyyyymmdd($sdate,'d');
	$result = (intVal(mktime (0,0,0,$tm,$td,$ty) - mktime (0,0,0,$sm,$sd,$sy))/86400)+1;
	return $result;
}

//해당 숫자에 맞는 다양한 요일 반환
function getWeeKNameTotal($target,$kind='kor'){
	switch($kind){
		case "kor":
			return getWeekNameKor($target);
			break;
		case "kd":
			return getWeekNameKor_Detail($target);
			break;
		case "ke":
			return getWeekNameKorEn($target);
			break;
		case "en":
			return getWeekNameEn($target);
			break;
		case "ed":
			return getWeekNameEn_detail($target);
			break;
		case "ch":
			return getWeekNameCh($target);
			break;
		case "kc":
			return getWeekNameKorCh($target);
			break;
		default:
			return getWeekNameKor($target);
			break;
	}

}

//해당 코드값에 맞는 한글 요일 반환
function getWeekNameKor($target){
	switch($target){
		case 0:
			return '일';
			break;
		case 1:
			return '월';
			break;
		case 2:
			return '화';
			break;
		case 3:
			return '수';
			break;
		case 4:
			return '목';
			break;
		case 5:
			return '금';
			break;
		case 6:
			return '토';
			break;
		

	}
}

//해당 코드값에 맞는 한글 상세 요일 반환
function getWeekNameKor_Detail($target){
	switch($target){
		case 0:
			return '일요일';
			break;
		case 1:
			return '월요일';
			break;
		case 2:
			return '화요일';
			break;
		case 3:
			return '수요일';
			break;
		case 4:
			return '목요일';
			break;
		case 5:
			return '금요일';
			break;
		case 6:
			return '토요일';
			break;
		

	}
}

//해당 코드값에 맞는 한자 요일 반환
function getWeekNameCh($target){
	switch($target){
		case 0:
			return '日';
			break;
		case 1:
			return '月';
			break;
		case 2:
			return '火';
			break;
		case 3:
			return '水';
			break;
		case 4:
			return '木';
			break;
		case 5:
			return '金';
			break;
		case 6:
			return '土';
			break;
	}
}

//해당 코드값에 맞는 한글 한자 요일 반환
function getWeekNameKor_Ch($target){
	switch($target){
		case 0:
			return '일(日)';
			break;
		case 1:
			return '월(月)';
			break;
		case 2:
			return '화(火)';
			break;
		case 3:
			return '수(水)';
			break;
		case 4:
			return '목(木)';
			break;
		case 5:
			return '금(金)';
			break;
		case 6:
			return '토(土)';
			break;
	}
}

//해당 코드값에 맞는 영문 요일 반환
function getWeekNameEn($target){
	switch($target){
		case 0:
			return 'Mon';
			break;
		case 1:
			return 'Tue';
			break;
		case 2:
			return 'Wed';
			break;
		case 3:
			return 'Thu';
			break;
		case 4:
			return 'Fri';
			break;
		case 5:
			return 'Sat';
			break;
		case 6:
			return 'Sun';
			break;
		default:
			return $target;
			break;
	}
}

//해당 코드값에 맞는 영문상세 요일 반환
function getWeekNameEn_detail($target){
	switch($target){
		case 0:
			return 'Sunday';
			break;
		case 1:
			return 'Monday';
			break;
		case 2:
			return 'Tuesday';
			break;
		case 3:
			return 'Wednesday';
			break;
		case 4:
			return 'Thursday';
			break;
		case 5:
			return 'Friday';
			break;
		case 6:
			return 'Satday';
			break;
	}
}

//해당 코드값에 맞는 한글 영문 요일 반환
function getWeekNameKorEn($target){
	switch($target){
		case 0:
			return '일(Sun)';
			break;
		case 1:
			return '월(Mon)';
			break;
		case 2:
			return '화(Tue)';
			break;
		case 3:
			return '수(Wed)';
			break;
		case 4:
			return '목(Thu)';
			break;
		case 5:
			return '금(Fri)';
			break;
		case 6:
			return '토(Sat)';
			break;
	}
}

//20050112와 같은 형태의 날짜를 2005년 8월 21일 형태로 바꿈
function getDateConvertKorString($target){
	$y = substr($target,0,4);
	$m = substr($target,4,2);
	$d = substr($target,6,2);

	$result = $y."년 ".$m."월";
	
	if(check_existence($d)){
			$result .= " ".$d."일";
	}

	return $result;
}

//기준일로부터 년월일 이전 이후 알아내기
function getDateFrevNextString($date,$num,$kind){
	$dateArray = explode("-",$date);
	$year = $dateArray[0];
	$month = $dateArray[1];
	$day = $dateArray[2];
	
	switch($kind){
		case "y":
			$result = date("Y-m-d",mktime(0,0,0,$month,$day,$year+$num));
			break;
		case "m":
			$result = date("Y-m-d",mktime(0,0,0,$month+$num,$day,$year));
			break;
		case "d":
			$result = date("Y-m-d",mktime(0,0,0,$month,$day+$num,$year));
			break;
	}
	
	return $result;
}

//datetime의 형태를 date만 반환하기
function getOnlyDateString($date){
	$result = substr($date,0,10);
	return $result;
}
?>
