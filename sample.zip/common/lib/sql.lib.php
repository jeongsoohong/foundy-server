<?
//==============================================================================
//  SQL 관련 함수
//==============================================================================


// mysql_query 와 mysql_error 를 한꺼번에 처리
function sql_query($sql)
{
    $result = mysql_query($sql) or die("<p>$sql<p>" . mysql_errno() . " : " .  mysql_error());
    return $result;
}


// 한행을 얻는다.
function sql_fetch($sql)
{
    $result = sql_query($sql);
    $row = @mysql_fetch_array($result);
    return $row;
}


// SQL PASSWORD 를 얻는다.
function sql_password($passwd)
{
    $sql = " SELECT PASSWORD('$passwd') ";
    $row = sql_fetch($sql);
    return $row[0];
}

//update 시 업데이트 할 데이터가 없으면 insert 하고 실행된 쿼리를 반환
function sql_updateInsert($sql,$sql2){
	
	$query = $sql;

	sql_query($query);

	if(mysql_affected_rows()==0){
		$query = $sql2;
		$result = @mysql_query($query);
	}
	return $query;
}

class mysql{
        var $DB_HOST;										//DB HOST
		var $DB_USER;                                       //DB 사용자
        var $DB_PASSWD;										//DB 암호
		var $DB_SELECT;										//SELECT DB
        var $db;                                            //db접속
        var $debug=false;                                   //디버그모드

        function mysql($host='', $user='', $passwd='',$selectdb) {        //DB 접속정보 초기화
                $this->DB_HOST=$host;
				$this->DB_USER=$user;
                $this->DB_PASSWD=$passwd;
				$this->DB_SELECT=$selectdb;
        }

        function con() {        //DB 접속
		$connect = mysql_connect($this->DB_HOST,$this->DB_USER,$this->DB_PASSWD) or die("DB Connect Error");
		@mysql_query(" set names utf8 ");
		$this->db = mysql_select_db($this->DB_SELECT, $connect);
		if (!$this->db) {
			echo "DB 접속 오류";
			exit;
		}
        }

        function discon() {        //DB 접속 해제
                return @mysql_close($this->db);
        }

        function error($mes) {        //에러메세지 출력
                $this->discon();
                echo "<script language=JavaScript>
        alert(\"$mes\");
        </script>";
                exit;
        }
 
//######################################################퀴리 날리기
        function query($query) {        //일반 퀴리
			if($this->debug) echo $query;

			$result = mysql_query($query) or die("<p>$sql<p>" . mysql_errno() . " : " .  mysql_error());
			return $result;
        }

        function querys($query) {        //여러개의 결과용 퀴리
                if($this->debug) echo $query;

                $result = mysql_query($query) or die("<p>$sql<p>" . mysql_errno() . " : " .  mysql_error());

                while ($row=mysql_fetch_array($result)) {
                        $value[]=$row;

                }

                @mysql_free_result($this->db);
                return $value;                                //배열형태로 전송
        }

        function queryone($query) {        //한개의 값만 출력
                if($this->debug) echo $query;

                $value = $this->fetch($query);
				$result = $value[0];
				@mysql_free_result($this->db);
				return $result;
        }

		function fetch($query){
			if($this->debug) echo $query;

            $result = $this->query($query);
			$row = @mysql_fetch_array($result);
			@mysql_free_result($this->db);
			return $row;
		}

}

?>