/* floater  */
// 플로터 : 상단을 기준으로 위치 설정
//ex) JSFX_FloatDiv("wing",880,143).floatIt(); //플로터 객체 아래에 삽입
var ns = (navigator.appName.indexOf("Netscape") != -1);
var d = document;
function JSFX_FloatDiv(id, sx, sy)
{
	var el=d.getElementById?d.getElementById(id):d.all?d.all[id]:d.layers[id];
	var px = document.layers ? "" : "px";
	window[id + "_obj"] = el;
	if(d.layers)el.style=el;
	el.cx = el.sx = sx;el.cy = el.sy = sy;
	el.sP=function(x,y){this.style.left=x+px;this.style.top=y+px;};

	el.floatIt=function()
	{
		var pX, pY;
		pX = (this.sx >= 0) ? 0 : ns ? innerWidth : 
		document.documentElement && document.documentElement.clientWidth ? 
		document.documentElement.clientWidth : document.body.clientWidth;
		pY = ns ? pageYOffset : document.documentElement && document.documentElement.scrollTop ? 
		document.documentElement.scrollTop : document.body.scrollTop;
		if(this.sy<0) 
		pY += ns ? innerHeight : document.documentElement && document.documentElement.clientHeight ? 
		document.documentElement.clientHeight : document.body.clientHeight;
		this.cx += (pX + this.sx - this.cx)/8;this.cy += (pY + this.sy - this.cy)/8;
		this.sP(this.cx, this.cy);
		setTimeout(this.id + "_obj.floatIt()", 40);
	}
	return el;
}

/*--------------------------------------------------------------------------*/
/*  main  script view
/*--------------------------------------------------------------------------*/
function showBx(id)
{
    var bx = document.getElementById(id);
    if (bx.style.display == 'block')
    {
        bx.style.display='none';
    }
    else
    {
        bx.style.display='block';
    }
}
/*--------------------------------------------------------------------------*/
/*  seogu
/*--------------------------------------------------------------------------*/
function showPop(id)
{
    var Pop = document.getElementById(id);
    if (Pop.style.display == 'block')
    {
        Pop.style.display='none';
    }
    else
    {
        Pop.style.display='block';
    }
}
/*--------------------------------------------------------------------------*/
/*  changeShowImg 
/*--------------------------------------------------------------------------*/
var idss = '';

function changeShowImg(img,ids,big,bg){
	//alert(idss);

	document.getElementById('pLayerImg'+big).src = img;

	if(idss!=ids && idss!=''){
		//alert('sum'+idss);
		document.getElementById('sum'+ids).style.background  = bg; 
		document.getElementById('sum'+idss).style.background   = '#fff'; 
	}else{
		//alert("2");
		document.getElementById('sum'+ids).style.background  = bg; 
		//document.getElementById('sum'+idss).style.background   = '#FFFFFF'; 
	}

	idss = ids;
	
}

/*--------------------------------------------------------------------------*/
/*  FAQ class="protectCon on"
/*--------------------------------------------------------------------------*/
function switchContents(switchId) {
	var switchCon = document.getElementById(switchId);
	var switchConDd = switchCon.getElementsByTagName("dd");
	var switchConDt = switchCon.getElementsByTagName("dt");
	var switchConA = switchCon.getElementsByTagName("a");
	
	for (i=0;switchConDd.length>i ;i++)
	{
		if (switchConDd[i].parentNode==switchCon)	{
			switchConDd[i].style.display="none";
		}
	}
	
	for (j=0;switchConA.length>j ;j++)
	{
		if (switchConA[j].parentNode.nodeName=="DT" && switchConA[j].parentNode.parentNode==switchCon)	{
			switchConA[j].onclick = function()	{
				if (document.getElementById(this.href.split("#")[1]) && document.getElementById(this.href.split("#")[1]).style.display=="block")	{
					document.getElementById(this.href.split("#")[1]).style.display="none";
					this.parentNode.className = "protectTitle";
				}
				else if (document.getElementById(this.href.split("#")[1]) && document.getElementById(this.href.split("#")[1]).style.display=="none")	{
					for (k=0;switchConDd.length>k ;k++)	{
						if (switchConDd[k].parentNode==switchCon)	{
							switchConDd[k].style.display="none";
						}
					}
					for (t=0;switchConDt.length>t ;t++)	{
						if (switchConDt[t].parentNode==switchCon)	{
							switchConDt[t].className = "protectTitle";
						}
					}
					document.getElementById(this.href.split("#")[1]).style.display="block";
					this.parentNode.className = "protectTitle on";
				}
				return false;
			}
		}
	}
}

/*--------------------------------------------------------------------------*/
/*	 PNG
/*--------------------------------------------------------------------------*/

function setPng24(obj) {
	obj.width=obj.height=1;
	obj.className=obj.className.replace(/\bpng24\b/i,'');
	obj.style.filter =
	"progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+ obj.src +"',sizingMethod='image');"
	obj.src=''; 
	return '';
}

/*--------------------------------------------------------------------------*/
/*	 rollover     */
/*--------------------------------------------------------------------------*/

function rollover(target, hover, current, focus) {
	$(target).each(function() {
		var isCurrent = current && this.src.match(current + '(\.gif|\.jpg|\.png)([\?].*|$)');
		this.src.match('(\.gif|\.jpg|\.png)([\?].*|$)');
		var ext = RegExp.$1;
		var search = (isCurrent) ? current + ext : ext;
		var replace_over = (isCurrent) ? current + ext : hover + ext;
		if(focus) var replace_down = (isCurrent) ? focus + ext : focus + ext;
		
		var out = this.src;
		var over = this.src.replace(search, replace_over);
		if(focus) var down = this.src.replace(search, replace_down);

		// preload
		new Image().src = over;
		if(focus) new Image().src = down;

		// page add
		$(this).bind('mouseover', function() { this.src = over; })
			.bind('mouseout', function() { this.src = out; });
		
		if(focus) $(this).bind('mousedown', function() { this.src = down; });
			
	});
}

/*--------------------------------------------------------------------------*/
/*	 MM_Behavior
/*--------------------------------------------------------------------------*/

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}


/********************************************************************
  Flash
*********************************************************************/
function flash(value, width, height){	//???
	document.writeln('<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="'+width+'" height="'+height+'">');
	document.writeln('<param name="movie" value="'+value+'">');
	document.writeln('<param name="quality" value="high">');
	document.writeln('<param name="wmode" value="transparent">');
	document.writeln('<param name="menu" value="false">');
	document.writeln('<embed src="'+value+'" width="'+width+'" height="'+height+'" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" wmode="transparent" menu="false"></embed>');
	document.writeln('</object>');
}

/** 마우스오버아웃
* desc: 아웃이미지가 img.gif 이면 오버이미지는 imgon.gif
* .gif 에 국한된 확장자를 범용으로 수정함.
* _imgtype 를 전역변수로 지정해서 내장함수(obj.src.replace)에서도 사용가능.
* ex) 상황별로 다른 함수 사용.
*/
function imgOver(imgEl){//ex) oneEl.onmouseover = imgOver("이미지id");
	if(imgEl){
		_imgtype = imgEl.src.substr(imgEl.src.length-3,imgEl.src.length-1);
		var where = imgEl.src.indexOf("_on."+_imgtype,0);
		if(where==-1) imgEl.src = imgEl.src.replace("."+_imgtype,"_on."+_imgtype);
	}
}
function imgOut(imgEl){//ex) oneEl.onmouseover = imgOut("이미지id");
	if(imgEl){
		_imgtype = imgEl.src.substr(imgEl.src.length-3,imgEl.src.length-1);
		var where = imgEl.src.indexOf("_on."+_imgtype,0);
		if(where!=-1) imgEl.src = imgEl.src.replace("_on."+_imgtype,"."+_imgtype);
	}
}
function menuOver(){//ex) imgEl.onmouseover = menuOver; aEl.onfocus = menuOver;
	var imgEl = (this.src)? this: this.getElementsByTagName("img")[0];
	if(imgEl) {
		_imgtype = imgEl.src.substr(imgEl.src.length-3,imgEl.src.length-1);
		var where = imgEl.src.indexOf("_on."+_imgtype,0);
		if(where==-1) imgEl.src = imgEl.src.replace("."+_imgtype,"_on."+_imgtype);
	}
}
function menuOut(){//ex) imgEl.onmouseout = menuOver; aEl.onblur = menuOut;
	var imgEl = (this.src)? this: this.getElementsByTagName("img")[0];
	if(imgEl) {
		_imgtype = imgEl.src.substr(imgEl.src.length-3,imgEl.src.length-1);
		var where = imgEl.src.indexOf("_on."+_imgtype,0);
		if(where!=-1) imgEl.src = imgEl.src.replace("_on."+_imgtype,"."+_imgtype);
	}
}
/** 이미지롤오버함수할당
* desc: 콘테이너 안의 모든 img 요소에 롤오버 함수를 할당한다.
* .gif 에 국한된 확장자를 범용으로 수정함.
* _imgtype 를 전역변수로 지정해서 내장함수(obj.src.replace)에서도 사용가능.
* ex) initImgRoll("이미지그룹id");
*/
function initImgRoll(containerId) {
 	var imgEl = document.getElementById(containerId).getElementsByTagName("img");
	if(imgEl){
		for(var i=0; i<imgEl.length; i++){
			var objImg = imgEl[i];
			_imgtype = objImg.src.substr(objImg.src.length-3,objImg.src.length-1);
			var where = objImg.src.indexOf("_on."+_imgtype,0);
			if (where==-1){ objImg.onmouseover = menuOver; objImg.onmouseout = menuOut; }
		}
	}
}

// 익스에서 지원되지 않는 함수 구현
function getElementsByClassName(classname,tag) {
	if(!tag) tag = "*";
	var anchs =  document.getElementsByTagName(tag);
	var total_anchs = anchs.length;
	var regexp = new RegExp('\\b' + classname + '\\b');
	var class_items = new Array();
	
	for(var i=0;i<total_anchs;i++) {
		var this_item = anchs[i];
		if(regexp.test(this_item.className)) class_items.push(this_item);
	}
	return class_items;
}

function changeTab(id,stnum,ednum) {
	containerId = "tabContents" + id;
	imageId 	= "tabImage" + id;
 	
 	var divEl = getElementsByClassName("tabcontent","div");
	if(divEl){
		for(var i=stnum; i<ednum; i++){
			if(divEl[i] == document.getElementById(containerId)){
				divEl[i].style.display = "block";
			}else{
				divEl[i].style.display = "none";
			}
		}
	}
	var imgEl = getElementsByClassName("tabImg","img");
 	//var imgEl = document.getElementById("tabContentsMenu").getElementsByTagName("img");
	if(imgEl){
		for(var i=stnum; i<ednum; i++){
			if(imgEl[i] == document.getElementById(imageId)){
				var objImg = imgEl[i];
				_imgtype = objImg.src.substr(objImg.src.length-3,objImg.src.length-1);
				var where = objImg.src.indexOf("_on."+_imgtype,0);
				if (where==-1){ objImg.src = objImg.src.replace("."+_imgtype,"_on."+_imgtype); }
			}else{
				var objImg = imgEl[i];
				_imgtype = objImg.src.substr(objImg.src.length-3,objImg.src.length-1);
				objImg.src = objImg.src.replace("_on."+_imgtype,"."+_imgtype);
			}
		}
	}

}