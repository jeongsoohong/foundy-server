<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<?
session_start();

session_unset(); // 모든 세션변수를 언레지스터 시켜줌
session_destroy(); // 세션해제함

$hostname = $_SERVER["HTTP_HOST"];
$gourl = "http://".$hostname."/index.php";
?>
<script language="javascript">
	document.location.href = "<?=$gourl?>";
</script>
