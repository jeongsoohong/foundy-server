<?
session_start();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>
  <script  src="http://code.jquery.com/jquery-latest.min.js"></script>
<?php 
  include_once("../../common/inc/inc_header.php");
  //등록일 경우
  if(check_existence($_SESSION["ss_id"])){
  	alert("로그인  되어 있습니다.");
  	exit();
  }
  $gourl = $_SERVER["HTTP_REFERER"];
  $hostname = $_SERVER["HTTP_HOST"];
  if(strpos($gourl,"member")>0 || $gourl==""){
  	$gourl = "http://".$hostname."/index.php";
  }else{
  	$gourl = $gourl;
  }
?>
</head>
<body>
 
 <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">SiteMap/Admin</h6>
          <h4 class="center white-text">사이트맵 /관리자</h4>
        </div>
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background3.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">
      
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<!-- <li class="col s4 th2"><a href="/user/site/privacy.php" target="_self" class="link_7th" >개인정보취급방침
</a>
				</li> -->
				<li class="col s6 th2"><a href="/user/site/sitemap.php" target="_self" class="link_7th">사이트맵</a>
				</li>
				<li class="col s6 th2"><a href="/admin/login/login.php" target="_self" class="link_7th link_7th_ov">관리자 로그인</a>
				</li>
			</ul>
		</div>
	</div>
   
   
    <div class="section">
	<form method="post" name="loginFrm" action="/admin/login/login_process.php">
	 <input type="hidden" name="gourl" value="<?=$gourl?>" />
     <div id="responsive" class="section scrollspy">
        <div class="con_title center">관리자 로그인</div>
        <div class="col s12">
        <div class="row">
         <div class="input-field col s6 offset-s3">
          <i class="material-icons prefix">&#xE853;</i>
          <input type="text" name="userid" value="" size="25" maxlength="20" class="materialize-validate"  id="name" required itemname="아이디" />
          <label for="name">아이디</label>
        </div>
        </div>
        <div class="row">
         <div class="input-field col s6 offset-s3">
          <i class="material-icons prefix">&#xE001;</i>
          <input type="password" name="userpw" value="" size="25" maxlength="20" class="materialize-validate" id="password" required itemname="비밀번호" />
          <label for="password">비밀번호</label>
        </div>
        </div>
        <div class="row center">         
          <button type="submit" class="waves-effect waves-light btn-large btn_a gray1">로그인</button>        
        </div>
		 </div>
      </div>
     </form>
     
	  </div>
	</div>
	
	<? include_once "../../common/inc/inc_footer.php" ?>
	
  </body>
</html>