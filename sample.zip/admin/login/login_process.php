<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<?
$DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];
include $DOCUMENT_ROOT."/common/config/dbconn.php";
//Request Form Parameter
$userid = $_REQUEST["userid"];
$userpw = $_REQUEST["userpw"];
$gourl = $_REQUEST["gourl"];

if(!check_existence($userid)){
	alert("ID를 입력하십시오.");
	exit();
}

if(!check_existence($userpw)){
	alert("비밀번호를 입력하십시오.");
	exit();
}

//id에 대한 비밀번호가 맞는지 조사
$sql = "select * from tbl_member where userid = '".$userid."'";
$row = $db->fetch($sql);

if(!check_existence($row[userid])){
	alert("로그인 정보를 확인해주세요.");
	exit();
}else{
	if($row[userpw] == $userpw){
		//로긴일자 업데이트
		$sql = "update tbl_member set loginCnt = loginCnt + 1, lcondate = now() where userid = '".$userid."'";
		$db->query($sql);
		
		session_start();
		//세션 등록
		$_SESSION["ss_id"] = $row["userid"];
		$_SESSION["ss_name"] = $row["username"];
		$_SESSION["ss_email"] = $row["email"];
		
?>
<script language="javascript">

	alert("<?=$row["username"]?>님이 로그인하셨습니다.\n마지막 로그인 한 시간 : <?=$row["lcondate"]?>");
	location.href="<?=$gourl?>";
</script>
<?
	}else{
		alert("로그인 정보를 확인해주세요.");
		exit();
	}
}
?>