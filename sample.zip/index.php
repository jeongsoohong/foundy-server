<?
session_start();

//로그인 한 사람만 글을 쓸수 있게 되어있는 경우
echo $_SESSION['ss_id'];
echo "<br>";
echo $_SESSION['ss_name'];
echo "<br>";
echo $isLogin;
echo "<br>";

include_once "./common/config/dbconn.php";
?>

<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>


  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="/common/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="/common/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="/common/css/main.css" type="text/css" rel="stylesheet" media="screen,projection"/>
</head>
<body>
<div id="bp"></div>
	<a href="#main" id="skipnav">본문 바로가기</a>
	<div id="wrap">
	<header id="header" class="header">
	<div class="header-wrap">
		 <nav class="row" role="navigation">
			<div class="nav-wrapper container">
		  	  <a id="logo-container" href="index.php" class="brand-logo center"><img src="/common/images/logo1.png"  alt="중문색달마을"/></a>
		  	  				  
			  <ul class="tabs tabs-transparent hide-on-med-and-down">
				<li class="col s2"><a href="user/town/town_01.php">중문색달마을</a></li>
				<li class="col s2"><a href="user/park/park_01.php">생수천 생태문화공원</a></li>
				<li class="col s2"><a href="user/natural/natural_01.php">색달동 자원</a></li>
				<li class="col s2"><a href="user/board/noticeBoard.php">커뮤니티</a></li>
				<li class="col s2"><a href="user/site/sitemap.php">사이트맵 /관리자</a></li>
			  </ul>

			  <ul id="nav-mobile" class="side-nav">
        <li><a href="/user/town/town_01.php">중문색달마을</a></li>
         <li><a href="/user/park/park_01.php">생수천 생태문화공원</a></li>
           <li><a href="/user/natural/natural_01.php">색달동 자원</a></li>
            <li><a href="/user/board/noticeBoard.php">커뮤니티</a></li>
             <li><a href="/user/site/sitemap.php">사이트맵/관리자</a></li>
      </ul>
			  <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
			</div>
		  </nav>
  		</div>
		</header>
		
<main id="main" role="main" class="main home">		
  <div id="main-wrap">

<div class="l-container">
<div class="l-content">
<section class="intro">
<h1 class="blind">홈</h1>
<div class="slider slider-intro">
  <div class="slide" data-small="">
<div class="slide-spacer">
<div class="f01">색다른 매력이 샘(SAEM) 솟는,</div>
<div class="f02"> 중문 색달 마을에 오신 것을 환영합니다.</div>
</div>
</div>
</div>
</section>

<section class="row news-latest">
<div class="col-t-6 news-latest-col">
<div class="news-latest-box">
<h2 class="news-latest-category">
  공지사항
</h2>
<div class="news-latest-ticker">
<ul class="news-latest-list">
<? $sql = "select * from tbl_notice order by reg_date desc limit 1";
   $result = mysql_query($sql);
   java_mysql_error_mesg();
   $row = mysql_fetch_object($result);?>
 <li><a href="user/board/noticeBoard.php?mode=2&uid=<?echo $row->uid?>>&page=1"><?echo $row->subject?></a></li>
 
</ul>
</div>
<span class="icon icon-arr-bold-right"></span>
</div>
</div>
<div class="col-t-6 news-latest-col">
<div class="news-latest-box">
<h2 class="news-latest-category">문의게시판</h2>
<div class="news-latest-ticker">
<ul class="news-latest-list">
<? $sql = "select * from tbl_freeboard order by reg_date desc limit 1";
   $result = mysql_query($sql);
   java_mysql_error_mesg();
   $row = mysql_fetch_object($result);?>
 <li><a href="user/board/freeBoardList.php?mode=2&uid=<?echo $row->uid?>&page=1"><?echo $row->subject?></a></li>
 </ul>
</div>
<span class="icon icon-arr-bold-right"></span>
</div>
</div>
</section>

<section class="banner">
<ul class="row banner-list">
 <li class="col-s-4 banner-item sp-view-bottom" style="background-image: url(/common/images/main_sv1.jpg)">
<a href="/user/town/town_01.php" class="block" data-id="24">
<div class="block-texts">
<span class="block-sub">마을이야기</span>
<h2 class="block-h">중문색달마을</h2>
<p class="block-desc">한여름밤의 꿈처럼 아름다운<br>중문색달마을 이야기</p>
</div>
</a>
</li>
 <li class="col-s-4 banner-item sp-view-bottom" style="background-image: url(/common/images/main_sv2.jpg)">
<a href="/user/park/park_01.php" class="block" data-id="38">
<div class="block-texts">
<span class="block-sub">체험이야기</span>
<h2 class="block-h">생수천 생태문화공원</h2>
<p class="block-desc">생수천 생태문화공원 시설소개와<br>체험프로그램 안내</p>
</div>
</a>
</li>
 <li class="col-s-4 banner-item sp-view-bottom" style="background-image: url(/common/images/main_sv3.jpg)">
<a href="/user/natural/natural_01.php" class="block" data-id="26">
<div class="block-texts">
<span class="block-sub">관광이야기</span>
<h2 class="block-h">주변관광지</h2>
<p class="block-desc">생수천과 우보악<br>중문관광단지와 중문색달해변</p>
</div>
</a>
</li>
</ul>
</section>

</div>
</div>

</div>
</main>   
   
 <footer class="page-footer">
    <div class="container center-align">
  <!--   <a href="site_01.html" class="btn">개인정보취급방침</a> -->
    <a href="user/site/sitemap.php" class="btn">사이트맵</a>
   <? if(isset($_SESSION['ss_id'])){?>
		<a href="/admin/login/logout.php" class="btn">관리자 로그아웃</a>
	<? } else{ ?> 
		<a href="/admin/login/login.php" class="btn">관리자 로그인</a>	
	<? }?>
     </div>
      
    
    <div class="footer-copyright">
      <div class="container center">
      제주특별자치도 서귀포시 색달로81번길 53 우) 63534 | Tel. 064-738-9360 Copyrightⓒ 중문색달마을 All right reserved
       </div>
    </div>
  </footer>

</div>
  <!--  Scripts-->
  <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script src="/common/js/materialize.js"></script>
  <script src="/common/js/init.js"></script>
	
  <script>
 /*  $(document).ready(function(){
	  require(['jquery'], function($){
		  jQuery.ajaxSetup({cache:false});
		  });
	  require(['sys/main'], function($){
	  });
  }) */

</script>

 <script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-78686211-1', 'auto');
ga('send', 'pageview');
</script>
  </body>
</html>
	