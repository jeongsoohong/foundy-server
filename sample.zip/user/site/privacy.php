<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>
  <script  src="http://code.jquery.com/jquery-latest.min.js"></script>
  <? include_once "../../common/inc/inc_header.php" ?>
</head>
<body>
 <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">Site Use Policy</h6>
          <h4 class="center white-text">사이트이용정책</h4>
        </div>
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background1.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">
      
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<li class="col s4 th2"><a href="/user/site/privacy.php" target="_self" class="link_7th link_7th_ov" >개인정보취급방침
</a>
				</li>
				<li class="col s4 th2"><a href="/user/site/sitemap.php" target="_self" class="link_7th">사이트맵</a>
				</li>
				<li class="col s4 th2"><a href="/admin/login/login.php" target="_self" class="link_7th">관리자 로그인</a>
				</li>
			</ul>
		</div>
	</div>
   
   
    <div class="section">

     <div id="responsive" class="section scrollspy">
        <div class="con_title center">개인정보취급방침</div>
        <div class="row">
         <div class="col s12">
			 <ul>
        		 <li>1. 개인정보취급방침</li>
				 <li>2. 개인정보취급방침</li>
				 <li>3. 개인정보취급방침</li>
				 <li>4. 개인정보취급방침</li>
				 <li>5. 개인정보취급방침</li>
				 <li>6. 개인정보취급방침</li>
				 <li>7. 개인정보취급방침</li>
				 <li>8. 개인정보취급방침</li>
			 </ul>
          </div>
          
			
          
        </div>
       
      </div>

 

	  </div>
	</div>
	
	<? include_once "../../common/inc/inc_footer.php" ?>

  </body>
</html>
