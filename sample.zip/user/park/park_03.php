<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>
	<script  src="http://code.jquery.com/jquery-latest.min.js"></script>
  <? include_once "../../common/inc/inc_header.php" ?>
</head>
<body>
 <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">Natural Attractions Park</h6>
          <h4 class="center white-text">생수천 생태문화공원</h4>
        </div>
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background5.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">
      
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<li class="col m4 th2"><a href="park_01.php" target="_self" class="link_5th" >생수천 생태문화공원소개
</a>
				</li>
				<li class="col m4 th2"><a href="park_02.php" target="_self" class="link_5th">시설소개</a>
				</li>
				<li class="col m4 th2"><a href="park_03.php" target="_self" class="link_5th link_5th_ov">체험프로그램안내</a>
				</li>
			</ul>
		</div>
	</div>
   
   
    <div class="section">

     <div id="responsive" class="section scrollspy">
        <div class="con_title center">체험프로그램안내</div>
        <div class="row">
            <div class="col s12 center">
             <img src="../../common/images/nopage.jpg"  alt=""/> 
            </div>
        </div>
       
      </div>

 

	  </div>
	</div>
	
		<? include_once "../../common/inc/inc_footer.php" ?>

  </body>
</html>
