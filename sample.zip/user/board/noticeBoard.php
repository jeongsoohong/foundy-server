<? 
session_start();
$code 		= "tbl_notice";
include_once("../../common/config/board_config.php");
$mode 		= trim($_GET[mode]);
if(!$mode)
	$mode = 1;
else
	$mode = (int)$mode;

$uid 		= trim($_GET[uid]);
$page 		= trim($_GET[page]);
if(!$page)
	$page = 1;
else
	$page = (int)$page;

$this_url 	= $_SERVER[PHP_SELF];

//검색할 경우
$key 		= trim($_GET[key]);
$searchword	= trim($_GET[searchword]);
if($searchword){
	$add_url = "&amp;key=".$key."&amp;searchword=".urlencode($searchword);
}

$board_date = "2015-12-31";

?>


<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title></title>
     <script  src="http://code.jquery.com/jquery-latest.min.js"></script>
     <? include_once "../../common/inc/inc_header.php" ?>
</head>
<body>
 <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">Community</h6>
          <h4 class="center white-text">커뮤니티</h4>
        </div>       
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background4.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">      
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<li class="col s6 th2"><a href="/user/board/noticeBoard.php" target="_self" class="link_2th link_2th_ov" >공지사항</a>
				</li>
				<li class="col s6 th2"><a href="/user/board/freeBoardList.php" target="_self" class="link_2th">문의게시판</a>
				</li>
			</ul>
		</div>
	</div>
   
    <div class="section">

     <div id="responsive" class="section scrollspy">
        <div class="con_title center">공지사항</div>
<?
switch ($mode)
{
	case (1) :
		include_once("notice/list.php");
		break;
	case (2) :
		include_once("notice/view.php");
		break;
	case (3) :
		include_once("notice/write.php");
		break;
	case (5) :
		include_once("notice/modify.php");
		break;
	case (6) :
		include_once("notice/delete.php");
		break;
	default :
		include_once("notice/list.php");
		break;
}
?>
		</div>
	</div>
</div>
<? include_once "../../common/inc/inc_footer.php" ?>
			
</body>
</html>