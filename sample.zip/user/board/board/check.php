<?
//로그인 한 사람만 글을 쓸수 있게 되어있는 경우
/* if($isLogin && !check_existence($_SESSION["ss_id"])){
	alert("로그인을 하지 않으셨거나 세션이 끊겼습니다.\\n다시 로그인하시기 바랍니다.");
	exit();
} */
$query = mysql_query("select * from $code where uid='$uid'");
java_mysql_error_mesg();
$query_array = mysql_fetch_array($query);
	$writer = $query_array[writer]; #작성자
	$email  = $query_array[email]; #E - mail
	$subject = $query_array[subject]; #제 목
?>
                        <!--삭제 시작 -->
                        <form name="check_form" method="post" action="board/board_exe.php?mode=check" >
                        <input type="hidden" name="code" value="<?=$code?>">
                        <input type="hidden" name="uid" value="<?=$uid?>">
                        <input type="hidden" name="page" value="<?=$page?>" />
                        <input type="hidden" name="this_url" value="<?=$this_url?>" />
                        <input type="hidden" name="add_url" value="<?=$add_url?>" />
                       
	                       <div class="check-pw" style="">
								<div class="standard" style="float:none; text-align:center;">
									<div style="display:inline-block; text-align:left;">
				                        <span class="col-green apply-block mar-bo-10 forleftt">* 비밀번호 Password</span>
				                        <input name="passwd" type="password" id="textfield" size="15" maxlength="30" required itemname="Password" placeholder="글 작성 시 등록한 비밀번호를 입력하세요.">
				                        <div class="fon-gray" style="margin-top:5px; font-size:12px;">비밀번호를 잊으신 분은 사무국으로 연락 바랍니다.</div>
				                         <div style="text-align:center; margin-top:40px;">
					                    	<button class="btn btn-backgreen qjxms">확인</button>
					                    	<button onclick="history.back();return false;" class="btn btn-outgreen qjxms">취소</button>
					                    </div>   
			                        </div>
			                    </div> 
			                                      
	                       </div>
                       
                       
                       
                       
                       
                       
                       
                  <!--       <table width="100%" border="0" cellpadding="0" cellspacing="0">
                          
                          <tr> 
                            <td height="25"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr> 
                                  <td width="80" style="padding-top:3px"><div align="center">Password</div></td>
                                  <td width="10"><img src="/images/common/line02.gif"></td>
                                  <td style="padding-top:3px" align="left"><input name="passwd" type="password" id="textfield" style="font-size:9pt;BORDER: #ECECEC 1px solid; height:17px; BACKGROUND-COLOR: #ECECEC" size="15" maxlength="30" required itemname="Password"></td>
                                </tr>
                              </table></td>
                          </tr>
                          <tr> 
                            <td height="5"></td>
                          </tr>
                          <tr> 
                            <td align="right">-->
                               <!-- <input type="image" src="/images/bbs/btn_delete.gif">&nbsp; -->
                              <!--  <button>확인</button>
                               <a href="#" onclick="history.back();return false;"><img src="/images/bbs/btn_cancel.gif"></a>
                            </td>
                          </tr>
                        </table>  -->
                        
                        
                        
                        
                        </form>
                        <!--삭제 끝 -->