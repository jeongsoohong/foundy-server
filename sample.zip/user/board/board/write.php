<?
//로그인 한 사람만 글을 쓸수 있게 되어있는 경우
/* if($isLogin && !check_existence($_SESSION["ss_id"])){
	alert("로그인을 하지 않으셨거나 세션이 끊겼습니다.\\n다시 로그인하시기 바랍니다.");
	exit();
} */
if($isNoRobot){
	//스팸글 방지
	include "norobot.php";
}
if($isNick){
	$w_name = $_SESSION["ss_nick"];
}else{
	$w_name = $_SESSION["ss_name"];
}
?>
    <div class="row pt0010">
    <form class="col s12" name="check_form" method="post" action="board/board_exe.php?mode=register" onsubmit="return check_send(this);">
    	<input type="hidden" name="code" value="<?=$code?>">
        <input type="hidden" name="userid" value="<?=$_SESSION['ss_id']?>" />
        <input type="hidden" name="sessionKey" value="<?=$_SESSION[ss_norobot_key]?>" />
        <input type="hidden" name="this_url" value="<?=$this_url?>" />
     <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">mode_edit</i>
          <input id="title" type="text" class="validate" name="subject" maxlength="100" required>
          <label for="title">제목</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <i class="material-icons prefix">mode_edit</i>
          <input id="name" type="text" class="materialize-validate"  name="writer" maxlength="30" required>
          <label for="name">작성자</label>
        </div>
        <div class="input-field col s6">
          <i class="material-icons prefix">mode_edit</i>
          <input id="password" type="password" class="materialize-validate" name="passwd" maxlength="30" required>
          <label for="password">비밀번호</label>
        </div>
        
        <div class="row right-align">
        <div class="col s12">
		  <input id="pwchk" type="checkbox" class="materialize-validate" name="openyn">
          <label for="pwchk">비밀글체크</label>       
        </div>
      </div>
        
      </div>
      
      <div class="row">
       <div class="input-field col s12">
          <i class="material-icons prefix">mode_edit</i>
          <textarea id="icon_prefix2" class="materialize-textarea"  name="contents" required></textarea>
          <label for="icon_prefix2">글내용</label>
        </div>
        <? if ($is_norobot) { ?>
         <div class="mar-to-20">
				<tr>
					<td height="25">
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
                                  <tr> 
                                    <td style="padding-top:3px; padding-right:5px;">
                                    	<div align="center"><?=$norobot_str?></div>
                                    </td>
                                    <td style="">
                                    	<div>왼쪽의 글자중<FONT COLOR="red"> 빨간글자만</FONT> 순서대로 입력하세요.(스팸글 방지)</div>
                                    	<input type=text name="wr_key" size="10" style=" border: 1px solid #dddce1; height:30px; BACKGROUND-COLOR: #f9f9f9; border-radius:5px;" required itemname="스팸글 방지">
                                    </td>
                                  </tr>
                            </table>
                     </td>
				</tr>
          </div>
		<? } ?>
      </div>
 	 <div class="mt10 right-align"> 
        <button class="waves-effect waves-light btn purple">저장</button> 
        <a href="<?=$this_url?>?page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">목록</a>
     </div>
    </form>
  </div>
            
