<?
$query = mysql_query("select * from $code where uid='$uid'");
java_mysql_error_mesg();
$query_array = mysql_fetch_array($query);

$writer 		= $query_array[writer]; #작성자
$email  		= $query_array[email]; #E - mail
$Reg_Day 	= $query_array[reg_date]; #작성일
$subject 	= $query_array[subject]; #제 목
$use_html 	= $query_array[use_html]; #Text - >0, html -> 1
$contents 	= $query_array[contents]; #내용
$counter		= $query_array[counter]; #조회수
if($use_html == "0"){
	$Contents = nl2br($contents);
}else{
	$Contents = $contents;
}

$Number = $counter + 1;
$update = mysql_query("update $code set counter='$Number' where uid='$uid'");
java_mysql_error_mesg();
?>
 <div class="row">
          <div class="col s12">
            <table class="bordered">
              <thead>
                <tr>
					<th class="q_title">
						<p><?=$subject?></p>
               			<span class="left">작성자 : <?=$writer?></span> 
               			<span class="right">날짜 : <?=$Reg_Day?></span>
               		</th>                    
                </tr>
              </thead>
              <tbody>
                <tr>                  
                  <td class="content">
                  	<?=$Contents?>
                  </td>               
                </tr>            
              </tbody>
            </table>
            <div class="mt10 right-align"> 
            	<a href="<?=$this_url?>?page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">목록</a>
            </div>
            <div>
             	<a href="<?=$this_url?>?mode=4&amp;uid=<?=$uid?>&amp;page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">답글</a>
                <a href="<?=$this_url?>?mode=5&amp;uid=<?=$uid?>&amp;page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">수정</a>
                <a href="<?=$this_url?>?mode=6&amp;uid=<?=$uid?>&amp;page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">삭제</a>
            </div>
    	</div>
</div>
        