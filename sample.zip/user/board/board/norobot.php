<?
/*
**  $norobot_str 와 $_SESSION[ss_norobot_key] 을 반환함
*/

// seed with microseconds
function make_seed() {
   list($usec, $sec) = explode(' ', microtime());
   return (float) $sec + ((float) $usec * 100000);
}

// 자동등록기를 막기 위해 난수발생
$is_norobot = true;
if ($is_norobot) {
    // 임의의 md5 문자열을 생성
    $tmp_str = substr(md5(time()),0,10);
    // 난수 발생기
    srand(make_seed());
    $keylen = strlen($tmp_str);
    $div = (int)($keylen / 2);
    while (count($arr) < 3) {
        unset($arr);
        for ($i=0; $i<$keylen; $i++) {
            $rnd = rand(1, $keylen);
            $arr[$rnd] = $rnd;
            if ($rnd > $div) { break; }
        }
    }
    
    // 배열에 저장된 숫자를 차례대로 정렬
    sort($arr);
    
    $norobot_key = "";
    $norobot_str = "";
    $m = 0;
    for ($i=0; $i<count($arr); $i++) {
        for ($k=$m; $k<$arr[$i]-1; $k++) { 
            $norobot_str .= $tmp_str[$k];
        }
        $norobot_str .= "<font size=3 color=#FF0000><b>{$tmp_str[$k]}</b></font>";
        $norobot_key .= $tmp_str[$k];
        $m = $k + 1;
    }
    
    if ($m < $keylen) {
        for ($k=$m; $k<$keylen; $k++) {
            $norobot_str .= $tmp_str[$k];
        }
    }
    
    # 3.09 추가
    //session_register("ss_norobot_key");
    
    // 입력일때 자동등록방지 사용
    $ss_norobot_key = $_SESSION["ss_norobot_key"] = $norobot_key;
    $is_norobot = true;
}
?>