<?
//로그인 한 사람만 글을 쓸수 있게 되어있는 경우
/* if($isLogin && !check_existence($_SESSION["ss_id"])){
	alert("로그인을 하지 않으셨거나 세션이 끊겼습니다.\\n다시 로그인하시기 바랍니다.");
	exit();
} */
$query = mysql_query("select * from $code where uid='$uid'");
java_mysql_error_mesg();
$query_array = mysql_fetch_array($query);
	$writer = $query_array[writer]; #작성자
	$subject = $query_array[subject]; #제 목
	$email   = $query_array[email]; #E-mail
	$use_html = $query_array[use_html]; #Text -> 0, html -> 1
	$contents = $query_array[contents]; #내 용
?>
 <div class="row pt0010">
    <form class="col s12" name="check_form" method="post" action="board/board_exe.php?mode=modify" onsubmit="return check_send(this);">
    	<input type="hidden" name="code" value="<?=$code?>" />
        <input type="hidden" name="uid" value="<?=$uid?>" />
        <input type="hidden" name="page" value="<?=$page?>" />
        <input type="hidden" name="this_url" value="<?=$this_url?>" />
        <input type="hidden" name="add_url" value="<?=$add_url?>" />
      <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">mode_edit</i>
          <input id="title" type="text" class="validate" name="subject" maxlength="100" value="<?echo"$subject"?>" required>
          <label for="title">제목</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6">
          <i class="material-icons prefix">mode_edit</i>
          <input id="name" type="text" class="materialize-validate"  name="writer" maxlength="30" value="<?=$writer?>" readOnly required>
          <label for="name">작성자</label>
        </div>
        <?php if(!check_existence($_SESSION['ss_id'])){?>
        <div class="input-field col s6">
          <i class="material-icons prefix">mode_edit</i>
          <input id="password" type="password" class="materialize-validate" name="passwd" maxlength="30" required>
          <label for="password">비밀번호</label>
        </div>
        <?php }?>
        <div class="row right-align">
        <div class="col s12">
		  <input id="pwchk" type="checkbox" class="materialize-validate" name="openyn">
          <label for="pwchk">비밀글체크</label>       
        </div>
    	</div>
       <!--  <div class="input-field col s6">
          <i class="material-icons prefix">mode_edit</i>
          <input id="pwchk" type="checkbox" class="materialize-validate" name="openyn">
          <label for="pwchk">비밀글체크</label>
        </div> -->
        
      </div>
      
      <div class="row">
       <div class="input-field col s12">
          <i class="material-icons prefix">mode_edit</i>
          <textarea id="icon_prefix2" class="materialize-textarea"  name="contents" required><?echo"$contents"?></textarea>
          <label for="icon_prefix2">글내용</label>
        </div>
        <? if ($is_norobot) { ?>
         <div class="mar-to-20">
				<tr>
					<td height="25">
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
                                  <tr> 
                                    <td style="padding-top:3px; padding-right:5px;">
                                    	<div align="center"><?=$norobot_str?></div>
                                    </td>
                                    <td style="">
                                    	<div>왼쪽의 글자중<FONT COLOR="red"> 빨간글자만</FONT> 순서대로 입력하세요.(스팸글 방지)</div>
                                    	<input type=text name="wr_key" size="10" style=" border: 1px solid #dddce1; height:30px; BACKGROUND-COLOR: #f9f9f9; border-radius:5px;" required itemname="스팸글 방지">
                                    </td>
                                  </tr>
                            </table>
                     </td>
				</tr>
          </div>
		<? } ?>
      </div>
 	 <div class="mt10 right-align"> 
        <button class="waves-effect waves-light btn purple">저장</button> 
        <a href="#" onclick="history.back();return false;" class="waves-effect waves-light btn gray1">목록</a>
     </div>
    </form>
  </div>
