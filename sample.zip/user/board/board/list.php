<?
$num_per_page = 10;
$num_per_block = 10;

if($board_date)
	$where = " where reg_date >= '$board_date' ";
else
	$where = " where 1 ";
if($searchword){
	$where .= " and $key like '%$searchword%' ";
}
$where .= "order by fid desc, thread ASC";
?>
<?
$Today = date("Y-m-d");
$query = mysql_query("select uid from $code $where");
java_mysql_error_mesg();
$query_number = mysql_num_rows($query);

$first = $num_per_page * ($page - 1);
$limit = "limit $first, $num_per_page";

$number = $query_number - $first;
$Check_no = 0;
$query1 = mysql_query("select * from $code $where $limit");
java_mysql_error_mesg(); 
?>
 <div class="row">
      						<!--검색 시작 -->
<?
include_once("../../common/inc/inc_search.php");
?>
                              <!--검색 끝 -->

          <div class="col s12">
            
            <table class="highlight centered bordered">
              <thead>
                <tr>
                    <th data-field="number">번호</th>
                    <th data-field="title">제목</th>
                    <th data-field="name">작성자</th>
                    <th data-field="date">날짜</th>
                    <th>조회수</th>
                </tr>
              </thead>
			  <tbody>
<?php 
while($query_array = mysql_fetch_array($query1)){
	  $uid		= $query_array[uid]; #키값
	  $ref		= $query_array[ref]; #키값
	  $thread	= $query_array[thread]; #키값
	  $reply_space = strlen($thread);
	  $space	= strlen($thread) - 1;
	  $subject  = $query_array[subject]; #제목
	  $writer   = $query_array[writer]; #작성자
	  $email	= $query_array[email]; #Email
	  $reg_date = $query_array[reg_date]; #작성일
	  $counter  = $query_array[counter]; #조회수
	  $openyn   = $query_array[open_yn]; #비밀글
?>

                            <tr>
                                <td><?=$number?></td>
								<?
								
								//리플
								if(strlen($thread) > 1 ) {
								?>
								    <td class="left" style="text-align:left"><?php echo str_repeat('&nbsp&nbsp&nbsp', strlen($thread))?><i class="material-icons f_s20 gray">&#xE5DA;</i><a href="<?=$this_url?>?mode=<?php if($openyn=='N' && $_SESSION['ss_id']==null){?>7<?php }else{ ?>2<?php } ?>&amp;uid=<?=$uid?>&amp;page=<?=$page?><?=$add_url?>" onfocus="this.blur();"><?=$subject?><?php if($openyn=='N'){?><i class="material-icons f_s18 gray">&#xE899;</i><?php }?></a></td>                            
								<?php 	
								
								}else{
								?>
									<td class="left" style="text-align:left"><a href="<?=$this_url?>?mode=<?php if($openyn=='N' && $_SESSION['ss_id']==null){?>7<?php }else{ ?>2<?php } ?>&amp;uid=<?=$uid?>&amp;page=<?=$page?><?=$add_url?>" onfocus="this.blur();"><?=$subject?><?php if($openyn=='N'){?><i class="material-icons f_s18 gray">&#xE899;</i><?php }?></a></td>
								<?php 
								}
								?>
                                <td><?=$writer?></td>
                                <td><?=$reg_date?></td>
                                <td><?=$counter?></td>
                            </tr>

                          
<?
	$number --;
}
?>
<?
 if($query_number == 0){
?>
                          <tr> 
                            <td colspan="5" align="center">등록된 글이 없습니다.</td>
                          </tr>
<?
} 
?>

  						</tbody>
                    </table>
                <div class="mt10 right-align"> 
                	<a href="<?=$this_url?>?mode=3&amp;page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">글쓰기</a>
                </div>
            </div>
          </div>
<?
include_once("../../common/inc/inc_page.php");
?>