<?
session_start();
$DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];

$query = mysql_query("select * from $code where uid='$uid'");
java_mysql_error_mesg();
$query_array = mysql_fetch_array($query);
     $writer = $query_array[writer]; #작성자
	 $subject = $query_array[subject]; #제 목
	 $email   = $query_array[email]; #E-mail
	 $use_html = $query_array[use_html]; #Text -> 0, html -> 1
	 $contents = $query_array[contents]; #내 용

?>

 <div class="row pt0010">
    <form class="col s12" name="check_form" method="post" action="notice/board_exe.php?mode=modify">
	    <input type="hidden" name="code" value="<?echo"$code"?>">
		<input type="hidden" name="uid" value="<?echo"$uid"?>">
		<input type="hidden" name="page" value="<?echo"$page"?>">
		<input type="hidden" name="searchDate" value="<?=$searchDate?>">
		<input type="hidden" name="this_url" value="<?=$this_url?>" />
	     <div class="row">
	        <div class="input-field col s12">
	          <i class="material-icons prefix">mode_edit</i>
	          <input id="title" type="text" class="validate" name="subject" size="60" maxlength="150"  value="<?echo"$subject"?>">
	          <label for="title">제목</label>
	        </div>
	      </div>
	     
	      <div class="row">
	       <div class="input-field col s12">
	          <i class="material-icons prefix">mode_edit</i>
	          <textarea id="icon_prefix2" class="materialize-textarea" name="contents" maxlength="1000"><?echo"$contents"?></textarea>
	          <label for="icon_prefix2">글내용</label>
	        </div>
	      </div>
	      
	      <div class="mt10 right-align"> 
	      	<button type="submit" class="waves-effect waves-light btn purple" name="submit">저장</button> 
	      	<a href="<?=$this_url?>?page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">목록</a>
	      </div>
	      
   </form>
 </div>
</body>
</html>
