<?
session_start();
$num_per_page = 10;
$num_per_block = 10;

if($board_date)
	$where = " where reg_date >= '$board_date' ";
else
	$where = " where 1 ";
if($searchword){
	$where .= " and $key like '%$searchword%' ";
}
$where .= "$sub_where2 order by top_title desc, uid desc, reg_date  desc";
?>
                       
<?
$query = mysql_query("select uid from $code $where");
java_mysql_error_mesg();
$query_number = mysql_num_rows($query);

$first = $num_per_page * ($page - 1);
$limit = "limit $first, $num_per_page";

$number = $query_number - $first;
$Check_no = 0;
$query1 = mysql_query("select * from $code $where $limit");
java_mysql_error_mesg();

?>

<div class="row"> 
         					<!--검색 시작 -->
<?
include_once("../../common/inc/inc_search.php");
?>
                              <!--검색 끝 -->
                     
         <div class="col s12">   
                 
            <table class="highlight centered bordered">
              <thead>
                <tr>
                    <th data-field="number">번호</th>
                    <th data-field="title">제목</th>
                    <th data-field="date">날짜</th>
                </tr>
              </thead>
                        <tbody>
                        <?php while($query1_array = mysql_fetch_array($query1)){?> 
                            <tr>
                                <td><?=$number?></td>
                                <td style="text-align:left"><a href="<?=$this_url?>?mode=2&amp;uid=<?=$query1_array[uid]?>&amp;page=<?=$page?><?=$add_url?>" onfocus="this.blur();"><?=$query1_array[subject]?></a></td>
                                <td><?=$query1_array[reg_date]?></td>
                            </tr>
                        <?
							$number --;
						}
						?>
                      
                          
<?
 if($query_number == 0){
?>
                          <tr> 
                            <td colspan="3" align="center">등록된 글이 없습니다.</td>
                          </tr>
<?
} 
?>
 						 </tbody>
                    </table>
        </div>
       </div>
                        
<?
include_once("../../common/inc/inc_page.php");
?>

	<? if(isset($_SESSION['ss_id'])){?>
		<div class="mt10 right-align">
        	<a href="<?=$this_url?>?mode=3&amp;page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">글쓰기</a>
        </div>
	<? } else{ ?>
	 
	<? }?>

                   