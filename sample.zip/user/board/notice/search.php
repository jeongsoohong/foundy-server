<script>
<!--
function key_search(){ 
 if(!document.search.searchword.value){
     window.alert('검색할 단어를 입력하세요');
     document.search.searchword.focus();
	 return;
   }
 document.search.submit();
}

function game_search(){
	document.search.submit();
}
//--->
</script>
  <form action="list.php" method="post" name="search" onSubmit="return false;">
  <input type="hidden" name="code" value="<?echo"$code"?>">
  <table border="0" width="640" align="center" cellspacing="0" cellpadding="0">
    <tr> 
      <td  width="320">
	  <div align="left">
	  조회하실 회차 : 
		  <select name="searchDate" size="1" class="INPUT">
		   <option value="">전체</option>
		   <option value="3" <?if($searchDate == '3'){?>selected<?}?>>3회</option> 
		   <option value="2" <?if($searchDate == '2'){?>selected<?}?>>2회</option>
		   <option value="1" <?if($searchDate == '1'){?>selected<?}?>>1회</option>
		  </select>
	     <input type="button" value="조회" onClick="game_search(this.form);">
	  </div>
      </td>
	  <td  width="320">
	  <div align="right">
		  <select name="key" size="1" class="INPUT">
		   <option value="subject">제 목</option>
		   <option value="contents">내 용</option>
		   <option value="writer">작성자</option>
		  </select>
	     <input type="text" name="searchword" size="20"  maxlength="40" class="INPUT">
	     <input type="button" value="검 색" onClick="key_search(this.form);">
	  </div>
      </td>
    </tr>
</table>
</form>
