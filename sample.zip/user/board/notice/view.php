<?
$query = mysql_query("select * from $code where uid='$uid'");
java_mysql_error_mesg();
$query_array = mysql_fetch_array($query);
$Reg_date 	= $query_array[reg_date]; #등록 날짜
$Counter	= $query_array[counter]; #카운터
$Subject  	= $query_array[subject]; #제 목
$writer   = $query_array[writer]; #작성자
//$email	= $query_array[email]; #Email
$Use_html	= $query_array[use_html]; #Text == > 0, Html --> 1
if($Use_html == "0"){
	$Content = nl2br($query_array[contents]);
}else{
	$Content = $query_array[contents];
}

$Number = $Counter + 1;
$update = mysql_query("update $code set counter='$Number' where uid='$uid'");
java_mysql_error_mesg();
?>
		 <div class="row">
			<div class="col s12">
                     <table class="bordered">
		              <thead>
		                <tr>
							<th class="title"><?=$Subject?><span class="right"><?=$Subject?></span></th>                    
		                </tr>
		              </thead>
		              <tbody>
		                <tr>                  
		                  <td class="content">
		                 	 <?=$Content?>
		                  </td>               
		                </tr>                
		                
		              </tbody>
		            </table>
                 
                    <div class="mt10 right-align"> <a href="<?=$this_url?>?page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">목록</a></div>
                
                <? if(isset($_SESSION['ss_id'])){?>
                	
                	<div class="mt10 right-align"> <a href="<?=$this_url?>?mode=5&amp;uid=<?=$uid?>&amp;page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">수정</a></div>
                	<div class="mt10 right-align"> <a href="<?=$this_url?>?mode=6&amp;uid=<?=$uid?>&amp;page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">삭제</a></div>
                	
				<? } else{ ?>
				 
				<? }?>
				</div>
			</div>
				