<?
session_start();
$DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];

include $DOCUMENT_ROOT."/common/config/dbconn.php";
//게시판 설정
include $DOCUMENT_ROOT."/common/config/board_config.php";

#
# 글 쓰 기
#
if($mode == "register"){
	//제 목
	if(!ereg("([^[:space:]]+)", $subject)) {
	    echo"
		 <script>
		   window.alert('제목을 입력하세요');
		   history.go(-1);
		 </script>
		   ";
	   exit;
	 }
	
	//내용
	if(!ereg("([^[:space:]]+)", $contents)) {
	    echo"
		 <script>
		   window.alert('내용을 입력해 주세요');
		   history.go(-1);
		 </script>
		   ";
	   exit;
	 }
	
	$is_bad = check_filter(getMarkBlankConvert($subject));   // 제목 필터링
	
	// 관리자가 아니라면
	if ($is_bad) {
		echo"
		 <script>
		   window.alert('제목에 부적합한 단어가 포함되어 있습니다.');
		   history.go(-1);
		 </script>
		   ";
	   exit;
	}
	
	$is_bad = check_filter(getMarkBlankConvert($contents));   // 내용 필터링
	
	// 관리자가 아니라면
	if ($is_bad) {
		echo"
		 <script>
		   window.alert('내용에 부적합한 단어가 포함되어 있습니다.');
		   history.go(-1);
		 </script>
		   ";
	   exit;
	}
	
	#등록날짜
	$reg_date = date("Y-m-d, H:i:s");
	$use_html = "0";
	#Text 및 html 인 경우
	if($use_html == "0"){
		$Contents = htmlspecialchars($contents,ENT_QUOTES,'ISO-8859-1');
		$Contents = $contents;
	}else{
		$Contents = $contents;
	}
	#새로 작성된 게시물의 fid(family id), uid(unique id)값을 결정한다.
	$Max_query = mysql_query("SELECT max(uid), max(fid) FROM $code");
	java_mysql_error_mesg();
	$max_row = mysql_fetch_row($Max_query);
	if($max_row[0]){
		$new_uid = $max_row[0] + 1;
	}else{
		$new_uid = 1;
	}
	if($max_row[1]) {
		$new_fid = $max_row[1] + 1;
	}else{
		$new_fid = 1;
	}
			
	$sql = "insert into $code set uid='$new_uid', fid='$new_fid', thread='A', subject='$subject', writer='$writer', passwd='$passwd', email='$email', use_html='$use_html', contents='$Contents', reg_date='$reg_date'";
	$query = mysql_query($sql);
	java_mysql_error_mesg();
	echo"
		<script>
		location.href = '/user/board/noticeBoard.php';
		window.alert('정상적으로 등록 되었습니다.');
		</script>
	";
	exit();
}

#
# 게시물 수정
#
if($mode == "modify"){
	//제 목
	if(!ereg("([^[:space:]]+)", $subject)) {
	    echo"
		 <script>
		   window.alert('제목을 입력하세요');
		   history.go(-1);
		 </script>
		   ";
	   exit;
	 }
	
	//내용
	if(!ereg("([^[:space:]]+)", $contents)) {
	    echo"
		 <script>
		   window.alert('내용을 입력해 주세요');
		   history.go(-1);
		 </script>
		   ";
	   exit;
	 }
	
	$is_bad = check_filter(getMarkBlankConvert($subject));   // 내용 필터링
	
	// 관리자가 아니라면
	if ($is_bad) {
		echo"
		 <script>
		   window.alert('제목 또는 내용에 부적합한 단어가 포함되어 있습니다.');
		   history.go(-1);
		 </script>
		   ";
	   exit;
	}
	
	$is_bad = check_filter(getMarkBlankConvert($contents));   // 내용 필터링
	
	// 관리자가 아니라면
	if ($is_bad) {
		echo"
		 <script>
		   window.alert('제목 또는 내용에 부적합한 단어가 포함되어 있습니다.');
		   history.go(-1);
		 </script>
		   ";
	   exit;
	}
	
	$check_query = mysql_query("select passwd from $code where uid='$uid'");
	java_mysql_error_mesg();
	$check_array = mysql_fetch_array($check_query);
	$Check_pwd = $check_array[passwd]; #비밀번호
	
	if($Check_pwd != $passwd){
		echo"
		  <script>
			window.alert('비밀번호가 일치하지 않습니다');
		    history.go(-1);
		   </script>
		   ";
		exit();
	}
	$query = mysql_query("update $code set  subject='$subject', writer='$writer', email='$email', contents='$contents' where uid='$uid'");
	echo"
	  <script>
		location.href = '$this_url?page=$page$add_url';
		window.alert('정상적으로 수정 되었습니다.');
	  </script>
	   ";
	exit();
}

#
# 게시물 삭제
#
if($mode == "delete"){
	if(!check_existence($_SESSION['ss_id'])){
		$check_query = mysql_query("select passwd from $code where uid='$uid'");
		java_mysql_error_mesg();
		$check_array = mysql_fetch_array($check_query);
		$Check_pwd = $check_array[passwd]; #비밀번호
		
		if($Check_pwd != $passwd){
			echo"
			  <script>
				window.alert('비밀번호가 일치하지 않습니다');
				history.go(-1);
			   </script>
			   ";
			exit();
		}
	}
	$query = mysql_query("delete from $code where uid='$uid'");
	java_mysql_error_mesg();
	
	echo"
	  <script>
		location.href = '$this_url?page=$page$add_url';
		window.alert('정상적으로 삭제 되었습니다.');
	  </script>
	   ";
	exit();
}
if($mode == "check"){
	$check_query = mysql_query("select passwd from $code where uid='$uid'");
	java_mysql_error_mesg();
	$check_array = mysql_fetch_array($check_query);
	$Check_pwd = $check_array[passwd]; #비밀번호
	
	if($Check_pwd != $passwd){
		echo"
		  <script>
			window.alert('비밀번호가 일치하지 않습니다');
			history.go(-1);
		   </script>
		   ";
		exit();
	}
	
	//$query = mysql_query("delete from $code where uid='$uid'");
	//java_mysql_error_mesg();
	
	echo"
	  <script>
		location.href = '$this_url?mode=2&uid=$uid&page=$page';
	  </script>
	   ";
	exit();
}

#
# 게시물 답변
#
if($mode == "reply"){
	//등록날짜
	$reg_date = date("Y-m-d");
	$use_html = "0";
	#Text 및 html 인 경우
	if($use_html == "0"){
		$Contents = htmlspecialchars($contents);
	}else{
		$Contents = $contents;
	}
	
	$is_bad = check_filter(getMarkBlankConvert($subject));   // 내용 필터링
	// 관리자가 아니라면
	if ($is_bad) {
		echo"
		 <script>
		   window.alert('제목 또는 내용에 부적합한 단어가 포함되어 있습니다.');
		   history.go(-1);
		 </script>
		   ";
	   exit;
	}
	
	$is_bad = check_filter(getMarkBlankConvert($contents));   // 내용 필터링
	// 관리자가 아니라면
	if ($is_bad) {
		echo"
		 <script>
		   window.alert('제목 또는 내용에 부적합한 단어가 포함되어 있습니다.');
		   history.go(-1);
		 </script>
		   ";
	   exit;
	}
	
	$query = "SELECT thread,right(thread,1) FROM $code WHERE fid = $fid AND length(thread) = length('$thread')+1 AND locate('$thread',thread) = 1 ORDER BY thread DESC LIMIT 1";
	$result = mysql_query($query);
	java_mysql_error_mesg();
	
	$rows = mysql_num_rows($result);
	if($rows) {
		$row = mysql_fetch_row($result);
		$thread_head = substr($row[0],0,-1);
		$thread_foot = ++$row[1];
		$new_thread = $thread_head . $thread_foot;
	}else{
		$new_thread = $thread . "A";
	}
	$sql = "insert into $code set fid='$fid', thread='$new_thread', writer='$writer', passwd='$passwd', email='$email', subject='$subject', contents='$Contents', reg_date='$reg_date', use_html='$use_html', userid='$userid'";
	$query = mysql_query($sql);
	java_mysql_error_mesg();
	echo"
	  <script>
		location.href = '$this_url';
		window.alert('정상적으로 등록 되었습니다.');
	  </script>
	   ";
	exit();
}
?>
<?
mysql_close();
?>