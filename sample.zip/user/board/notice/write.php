<?
session_start();
$DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];
//로그인 한 사람만 글을 쓸수 있게 되어있는 경우


if(!check_existence($_SESSION["ss_id"])){
	alert("로그인을 하지 않으셨거나 세션이 끊겼습니다.\\n다시 로그인하시기 바랍니다.");
	exit();
}

$email = $_SESSION["ss_email"];
$userid = $_SESSION["ss_id"];
$name = $_SESSION["ss_name"];
$code = "tbl_notice";

?>
 <div class="row pt0010">
    <form class="col s12" name="check_form" method="post" action="notice/board_exe.php?mode=register">
	    <input type="hidden" name="code" value="<?echo"$code"?>">
		<input type="hidden" name="searchDate" value="<?=$searchDate?>">
	     <div class="row">
	        <div class="input-field col s12">
	          <i class="material-icons prefix">mode_edit</i>
	          <input id="title" type="text" class="validate" name="subject" size="60" maxlength="150">
	          <label for="title">제목</label>
	        </div>
	      </div>
	     
	      <div class="row">
	       <div class="input-field col s12">
	          <i class="material-icons prefix">mode_edit</i>
	          <textarea id="icon_prefix2" class="materialize-textarea" name="contents" maxlength="1000"></textarea>
	          <label for="icon_prefix2">글내용</label>
	        </div>
	      </div>
	      
	      <div class="mt10 right-align"> 
	      	<button type="submit" class="waves-effect waves-light btn purple" name="submit">저장</button> 
	      	<a href="<?=$this_url?>?page=<?=$page?><?=$add_url?>" class="waves-effect waves-light btn gray1">목록</a>
	      </div>
	      
   </form>
 </div>
</body>
</html>
