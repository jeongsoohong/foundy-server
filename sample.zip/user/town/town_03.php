<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>
	<script  src="http://code.jquery.com/jquery-latest.min.js"></script>
  <? include_once "../../common/inc/inc_header.php" ?>
</head>
<body>
  <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">JungMunSaegDal Town</h6>
          <h4 class="center white-text">중문색달마을</h4>
        </div>       
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background2.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">      
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<li class="col s4 th2"><a href="town_01.php" target="_self" class="link_3th" >인사말</a>
				</li>
				<li class="col s4 th2"><a href="town_02.php" target="_self" class="link_3th">마을소개</a>
				</li>
				<li class="col s4 th2"><a href="town_03.php" target="_self" class="link_3th link_3th_ov">찾아오시는길</a>
				</li>
			</ul>
		</div>
	</div>
   
	    <div class="section">
	
	     <div id="responsive" class="section scrollspy">
	        <div class="con_title center">찾아오시는 길</div>
	        <div class="row">
	          <div class="col s12">
	            <div class="col s12 center">
	          <!-- * Daum 지도 - 지도퍼가기 -->
				<!-- 1. 지도 노드 -->
				<div id="daumRoughmapContainer1487728002355" class="root_daum_roughmap root_daum_roughmap_landing" style="width:100% !important"></div>
				
				<!--
					2. 설치 스크립트
					* 지도 퍼가기 서비스를 2개 이상 넣을 경우, 설치 스크립트는 하나만 삽입합니다.
				-->
				<script charset="UTF-8" class="daum_roughmap_loader_script" src="http://dmaps.daum.net/map_js_init/roughmapLoader.js"></script>
				
				<!-- 3. 실행 스크립트 -->
				<script charset="UTF-8">
					new daum.roughmap.Lander({
						"timestamp" : "1487728002355",
						"key" : "g4q8",
						"mapWidth" : "100%",
						"mapHeight" : "370"
					}).render();
				</script>
	          </div> 
	          <div class="col m6 mt30">
	          	<p class="map-s1"> 자가용 이용시</p>
	          	<ul>
	          		<li class="map-s2">네비게이션 검색</li>
	          		<li class="pl08">명칭 검색 : 색달 커뮤니티 센터</li>
	          		<li class="pl08">주소 검색 : 지번)제주특별자치도 서귀포시 색달동 2038</li>
	          		<li class="pl80">       도로명)제주특별자치도 서귀포시 색달로81번길 53</li>
	          	</ul>	          	
	          </div>
	          <div class="col m6 mt30">	          	
	          	<p class="map-s1"> 대중교통 이용 시</p>
	          	<ul>
	          		<li class="map-s2">961 버스 이용</li>
	          		<li class="pl08 mt04 mb15">중문관광단지 입구 하차 후 택시 이용</li>
	          		
		          	<li class="map-s2">702,781-1,781-2 버스 이용</li>
		          	<li class="pl08 mt04 mb15">중문관광단지 입구 하차 후 택시 이용</li>
		          	
		          	<li class="map-s2">7,100 버스 이용</li>
		          	<li class="pl08 mt04">색달동 정류장 하차 후 도보 10분 이내</li>
	          	</ul>
	          </div>
	         </div>           
	        </div>
	       
	      </div>
	
		 </div>
		
		</div>
	
		<? include_once "../../common/inc/inc_footer.php" ?>
  </body>
</html>
