<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>
	<script  src="http://code.jquery.com/jquery-latest.min.js"></script>
  <? include_once "../../common/inc/inc_header.php" ?>
</head>
<body>
  <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">JungMunSaegDal Town</h6>
          <h4 class="center white-text">중문색달마을</h4>
        </div>       
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background2.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">      
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<li class="col s4 th2"><a href="town_01.php" target="_self" class="link_3th" >인사말</a>
				</li>
				<li class="col s4 th2"><a href="town_02.php" target="_self" class="link_3th link_3th_ov">마을소개</a>
				</li>
				<li class="col s4 th2"><a href="town_03.php" target="_self" class="link_3th">찾아오시는길</a>
				</li>
			</ul>
		</div>
	</div>
   
	    <div class="section">
	
	     <div id="responsive" class="section scrollspy">
	        <div class="con_title center">마을 소개</div>
	        <div class="row">
	          <div class="col m2">
	          	<span class="greeting30 bold">위치 및 접근성</span>
	          </div>
	          <div class="col m9 greet-line mb50">
	          	<ul>
	          	 	<li class="li-tit">색달동은 구 서귀포시 서남쪽(예래동 위쪽)에 위치한 중산간 마을 이며, 면적은 2,032ha로 서귀포시 22개 법정동 가운데 규모가 큰 편 입니다.</li>
					<li class="li-tit">색달동 북쪽은 한라산 산악지대이며, 중간에는 돌오름 · 모라리오름 등의 낮은 산이 있고, 남쪽으로는 바다가 펼쳐져 있다.</li>
					<li class="pl13">동쪽으로는 천제천을 사이에 두고 중문동과 접해 있고, 서쪽은 색달천을 사이에 두고 상예동과, 서북쪽은 안덕면과 그리고 북쪽은 제주시 애월읍과 접해 있습니다.</li>
					<li class="li-tit">제주시청과는 약 40.5km (약 39분 소요)이며, 서귀포시청 제1청사와는 약 14.9km (약 17분 소요)에 위치해 있습니다.</li> 
	          	</ul>
	          </div>
	        </div>
	        <div class="row">
	          <div class="col m2">
	          	<span class="greeting30 bold">설촌 유래</span>
	          </div>
	          <div class="col m9 greet-line mb50">
	          	400여 년 전에 '색다리'에 광산 김씨가 들어와 살면서 설촌 하였다고 하며, 그 후 '망소계(望巢鷄)'지역에 김해 김씨가, '앞밧'에 경주 김씨가, '굿남케'이대에 진주 강씨와 군위 오씨가 들어와 살면서 마을이 커졌다고 전해집니다.

				색달동의 옛이름은 '막은다리' 또는 '막은골'로 한자로 색달(塞達)이라 하였고  색다릿내라는 내천 인근에 형성된 마을이라는 데서 유래한 것으로 전해집니다.
	          </div>
	        </div>
	        <div class="row">
	          <div class="col m2">
	          	<span class="greeting30 bold">지역특성</span>
	          </div>
	          <div class="col m9 greet-line mb20">
	          	<span class="greeting20 gr_blue">세계적 수준의 종합 관광 휴양 단지인 중문관광단지가 위치</span>
	          	<ul>
	          		<li class="li-tit">중문관광단지는 1971년 제주도 서귀포시 중문동 · 색달동 일대를 국제관광단지로 지정함으로써 조성되었으며 이곳은 국민 관광을 바탕으로 외국 관광객의 유치와 외국인의 투자를 유도하기 위한 제주 관광 개발의 전도 사업이었습니다.</li>
	          		<li class="li-tit">자연경관 보전 및 전통 한국미의 조형과 관광객의 장기 체류를 유도 할 수 있는 각종 레져 · 스포츠 시설을 조성하여 장기 체류형 관광단지로 개발 하였습니다.</li>
	          		<li class="li-tit">제주도 고유의 민속 문화와 풍물 관광을 바탕으로 카지노 · 면세쇼핑 · 골프 · 레저 · 바다관광 · 한라산등반 등을 연결하는 레크레이션 위주의 국제적인 종합 관광 휴양지 입니다.</li>
	          		<li class="li-tit">숙박시설로는 관광호텔 · 한국전통호텔 · 일반호텔 · 콘도미니엄(가족호텔) 등이 있으며 위락시설로는 관광식물원 · 관광농원 · 골프장 · 관광안내센터 및 면세점 · 카지노 · 선임교 · 천제루 등이 있습니다.</li>
	          	</ul>
	          </div>
	        </div>
	       
	      </div>
	
		 </div>
		
		</div>
	
		<? include_once "../../common/inc/inc_footer.php" ?>
  </body>
</html>
