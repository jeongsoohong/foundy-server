<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>
	<script  src="http://code.jquery.com/jquery-latest.min.js"></script>
  <? include_once "../../common/inc/inc_header.php" ?>
</head>
<body>
  <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">JungMunSaegDal Town</h6>
          <h4 class="center white-text">중문색달마을</h4>
        </div>       
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background2.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">      
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<li class="col s4 th2"><a href="town_01.php" target="_self" class="link_3th link_3th_ov" >인사말</a>
				</li>
				<li class="col s4 th2"><a href="town_02.php" target="_self" class="link_3th">마을소개</a>
				</li>
				<li class="col s4 th2"><a href="town_03.php" target="_self" class="link_3th">찾아오시는길</a>
				</li>
			</ul>
		</div>
	</div>
   
	    <div class="section">
	
	     <div id="responsive" class="section scrollspy">
	        <div class="con_title center">인사말</div>
	        <div class="row">
	          <div class="col s12">
	           	
	          </div>
	          
	          <div class="center">
	          	<img src="../../common/images/greeting.jpg" alt=""/> 
	          </div>
	          
	          <div class="center">
	       		<p class="greeting30">색다른 매력이<span class="gr_blue"> 샘(SAEM)</span> 솟는,</p>
	           	<p class="greeting24">중문 색달 마을에 오신 것을 환영합니다.</p>
	           	
	           	<p class="greeting20">연중 마르지 않는 생수천 처럼 웃음, 휴식, 체험이 있는 공간으로 안내합니다.</p>
	           	<p><span class="greeting20">색다른 감동으로</span> <span class="greeting30 bold">'기억하고, 머물고 싶은 색달 마을 문화 여행'</span></p>
	           	<br/>
	           	<p>제주특별자치도 서귀포시 색달동 2038</p>
	           	<p>전화) 064-738-9360</p>
	          </div>	        
	          
	          <!--div class="col s6">
	       		<p>색다를 매력이 샘(SAEM) 솟는,
	           	중문 색달 마을에 오신 것을 환영합니다.</p>
	           	
	           	<p>연중 마르지 않는 생수천 처럼 웃음, 휴식, 체험이 있는 공간으로 안내합니다.</p>
	           	<p>색다른 감동으로 '기억하고, 머물고 싶은 색달 마을 문화 여행'</p>
	           	
	           	<p>제주특별자치도 서귀포시 색달동 2038</p>
	           	<p>전화) 064-738-9360</p>
	          </div>
	          <div class="col s6">
	          	<img src="../../common/images/greeting.jpg" alt=""/> 
	          </div-->
	                    
	        </div>
	       
	      </div>
	
		 </div>
		
		</div>
	
		<? include_once "../../common/inc/inc_footer.php" ?>
  </body>
</html>
