<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>
  <script  src="http://code.jquery.com/jquery-latest.min.js"></script>
  <? include_once "../../common/inc/inc_header.php" ?>
</head>
<body>
  <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">Natural Resources</h6>
          <h4 class="center white-text">색달동 자원</h4>
        </div>
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background6.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">
         
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<li class="col s3 th2"><a href="natural_01.php" target="_self" class="link_6th link_6th_ov" >자연자원</a></li>
				<li class="col s3 th2"><a href="natural_02.php" target="_self" class="link_6th" >역사문화자원</a></li>	
				<li class="col s3 th2"><a href="natural_03.php" target="_self" class="link_6th" >사설관광자원</a></li>	
				<li class="col s3 th2"><a href="natural_04.php" target="_self" class="link_6th" >지역축제</a></li>					
			</ul>
		</div>
	</div>
   
    <div class="section">

     <div id="responsive" class="section scrollspy">
        <div class="con_title center">자연자원</div>
        <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural1.jpg" width="100%" alt="천제연폭포"/> </span>
          	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">천제연폭포</p>
          	 <span class="natural-s2">
          	 옥황상제를 모시는 7선녀들이 밤이면 내려와 목욕하며 놀았다해서 이름지어진 천제연 폭포. 울창한 난대림 사이로 웅장한 3단 폭포가 떨어지는 모습은 실로 장관입니다.<br/>
          	 제1폭포는 22m절벽으로 떨어져 수심 21m의 못을 이루고, 이는 다시 제2폭포,제3폭포가 되어 바다로 흘러갑니다.<br/>
          	천제연 계곡에는 아름다운 일곱 선녀상을 조각한 선임교라는 아치형 다리와 다리 너머에 '천제루'라고 불리는 8각정이 있습니다. <br/>
          	중문관광단지 내에 있는 천제연 폭포는 가장 손꼽는 관광지이며 천연 난대림 지대를 이루고 있어 한라산 천연 보호구역의 하나로 지정,보호되고 있습니다. </span>
          	
          </div>
        </div>
        <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural2.jpg" width="100%" alt="중문해수욕장"/></span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">중문해수욕장</p>
          	<span class="natural-s2">
          	남국의 정취를 느낄 수 있는 아열대 식물과 관광단지가 있습니다.   <br/>
암벽에 둘러싸인 이 곳은 하얀 모래와 제주도 특유의 검은 돌이 흑백의 조화를 이룹니다. 활처럼 굽은 긴 백사장과 흑,백, 적,회색의"진모살"이라 불리우는 모래색이 특이합니다.  <br/>
여름철이면 약간 물살이 거친 편. 젊음과 야성의 바다라고 할 수 있습니다. 윈드서핑등 해상 스포츠의 최적지, 윈드서핑은 바람조건이 여름보다는 겨울철이 더 좋습니다.  <br/>동편 어귀쪽에 물이 감도는 현상이 일어나므로 조심 해야 합니다.
          	</span>
          </div>
        </div>
        <div class="row">
          <div class="col m2">
           <span class="natural"><img src="../../common/images/natural3.jpg" width="100%" alt="생수천"/></span>           	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">생수천</p>
          	<span class="natural-s2">
          	감귤 재배가 전성기를 이루면서 논 농사는 하지 않고 있으나 이곳은 수 백년된 수목들이 울창하며 여름철 피서지로 알맞은 곳입니다. <br/> 특히 상당히 오래된 잣밤나무가 웅장한 자태로 서 있고 물의 용출량도 많은 곳입니다.  <br/>
          	1970년대까지는 참개, 장어, 민물새우가 서식하였습니다. 
          	</span>
          </div>
        </div>
        <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural4.jpg" width="100%" alt="1100습지"/></span>          
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">1100습지</p>
          	<span class="natural-s2">
          	1100고지 습지는 한라산 서쪽 산록을 관통하며, 제주시와 중문을 잇는 1100도로의 가장 높은 곳에 위치한 습지로 2009년 12월 람사르습지로 등록되었습니다. <br/>
1100고지 습지는 한라산 국립공원과 생물권보전지역안에 위치해 있으며, 13ha 면적으로 민물성 늪과 식물로 구성돼 생물다양성이 풍부한 고지대 습지로 분류되고 현무암으로 이루어진 한라산의 지질 특성으로 투수성이 높아 담수량은 많지 않으나, 야생동물들에게 중요한 물 공급원 역할을 하고 있습니다. <br/>
특히, 1100고지습지는 독특하고 희귀한 유형의 습지로 평가받고 있는데, 제주에서만 분포하는 한라산 고유식물인 한라물부추는 물론, 한국 고유식물로 멸종위기종 2급인 지리산오갈피가 지리산을 제외하고 유일하게 분포하고 있는 지역입니다.
또한, 멸종위기 야생동물 1급인 매, 2급인 말똥가리 · 조롱이, 천연기념물인 황조롱이 · 두견, 제주도 특산종인 제주도룡뇽 · 한라북방밑들이 메뚜기 · 제주밑들이 등이 서식하는 것으로 조사되었습니다.
          	</span>
          </div>
        </div>
        <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural5.jpg" width="100%" alt="갯깍주상절리대"/></span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">갯깍주상절리대</p>
          	<span class="natural-s2">
          	국내 최대 규모 주상절리대로 최대 높이 40m, 폭 1km를 자랑하고 있습니다. 
          	깎아 지르는 절벽처럼 깊게 솟은 주상절리 위로 푸른 숲을 얹은 모습과 흘러오는 예래천을 따라 청정함을 자랑하는 반딧불이 보호구역과 연결되는 이 주상절리는 숨은 아룸다움을 간직합니다. </span>
          </div>
        </div>
        <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural6.jpg" width="100%" alt="우보악(우보오름)"/></span> 
          	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">우보악(우보오름)</p>
          	<span class="natural-s2">
          	해발 301.4m, 높이 96m인 기생화산으로 소가 걸어가는 모습과 비슷한 형상이라고 하여 “우보오름“ 이라고 불리게 되었습니다. <br/>
          	고려 때 원나라가 제주도에 몽고말을 들여오면서 말을 기르는 말 목장이 있었습니다. </span>
          	
          	
          </div>
        </div>
        <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural7.jpg" width="100%" alt="중문관광단지"/></span> 
          	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">중문관광단지</p>
          	<span class="natural-s2">
          	제주도 남쪽 해안가에 있는 관광위락단지로써 사철기후가 따뜻합니다. <br/>
          	위락휴양시설, 숙박시설, 골프장, 컨벤션센터 등이 갖춰져 있으며, 제주도의 관광산업이 국제적인 수준으로 발전 할 수 있게 된 원동력이 된 곳 입니다. </span>
          	
          </div>
        </div>
        <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural8.jpg" width="100%" alt="올레8코스"/></span> 
          	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">올레8코스</p>
          	<span class="natural-s2">
          		월평 아왜낭목 부터 대평포구 까지 연결하는 올레코스로, 색달 하수종말처리장부터 대평포구까지는 장애인도 같이 걸을수 있는 올레길로 조성하였습니다. <br/>
          		전체적으로 해안길 위주의 바당올레 코스이며, 거리는 18.9km 로 시간은 6~7시간 정도 걸리는 코스 입니다.
          		</span>
          </div>
        </div>
        
      </div>

 

	  </div>
	</div>
	
		<? include_once "../../common/inc/inc_footer.php" ?>

  </body>
</html>
