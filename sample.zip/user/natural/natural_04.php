<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>
  <script  src="http://code.jquery.com/jquery-latest.min.js"></script>
  <? include_once "../../common/inc/inc_header.php" ?>
</head>
<body>
  <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">Natural Resources</h6>
          <h4 class="center white-text">색달동 자원</h4>
        </div>
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background6.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">
         
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<li class="col s3 th2"><a href="natural_01.php" target="_self" class="link_6th" >자연자원</a></li>
				<li class="col s3 th2"><a href="natural_02.php" target="_self" class="link_6th" >역사문화자원</a></li>	
				<li class="col s3 th2"><a href="natural_03.php" target="_self" class="link_6th" >사설관광자원</a></li>	
				<li class="col s3 th2"><a href="natural_04.php" target="_self" class="link_6th link_6th_ov" >지역축제</a></li>					
			</ul>
		</div>
	</div>
   
    <div class="section">

     <div id="responsive" class="section scrollspy">
        <div class="con_title center">지역축제</div>
        
         <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural23.jpg" width="100%" alt="중문비치 국제서핑대회"/></span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">중문비치 국제서핑대회</p>
          	<span class="natural-s2">
          	매년 6월경 중문색달해변에서 열리는 국제서핑 대회로 서귀포시생활체육회 주최, 서귀포시서핑연합회 주관으로 열리는 국제행사 입니다. <br/>국내 외 프로 및 아마추어 선수들이 참가하여 제주도의 대표적인 해양 레저스포츠대회로 자리매김 하고 있습니다. 
          	</span>
          </div>
        </div>     
        
  		<div class="row">
           <div class="col m2">
          <span class="natural"><img src="../../common/images/natural24.jpg" width="100%" alt="서귀포 겨울바다 펭귄 수영대회"/> </span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">서귀포 겨울바다 펭귄 수영대회</p>
          	<span class="natural-s2">
        		 겨울이 따뜻한 도시, 국토의 최남단에 위치한 휴양관광지 서귀포시에서 신년맞이 이색 체험행사인 '서귀포겨울바다 펭귄수영대회를 매년 개최하고 있습니다.<br/>
        		  묵은해의 흔적을 말끔히 지우고 희망찬 새해를 설계하며 아름다운 미래로 항진하는 감동의 드라마로 엮어내는 겨울바다 펭귄수영대회는 일종의 극기체험이자 일상과 상식의 틀을 벗어나려는 색다른 겨울체험관광이벤트 입니다. 세계적으로 이름난 중문해수욕장에서 넘실대는 겨울바다의 파도를 헤치며 서로의 화합과 우정을 나누는 펭귄수영대회는 다채로운 프로그램과 함께 짜릿한 감동을 만끽할 수 있습니다.
          	</span>
          </div> 
        </div>
        
        <div class="row">
           <div class="col m2">
          <span class="natural"><img src="../../common/images/natural25.jpg" width="100%" alt="예래생태마을 체험축제"/></span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">예래생태마을 체험축제</p>
          	<span class="natural-s2">
        		 제주시 예래동은 오름, 하천, 해변, 동굴유적, 연대, 고인돌 등 천혜의 자연과 문화가 어우러진 생태마을 입니다. <br/>시원스레 부서지는 해변의 파도와 시원한 용천수가 만나는 논짓물! 올여름 이곳에서 멋진 추억을 만들어 보시길 바랍니다. <br/>
        		 더불어 주변 해변에서는 각종 조개류 채취와 낚시도 즐길 수 있어 체험 피서지로도 각광을 받고 있고 반딧불이 서식지가 있는 곳 입니다. <br/>
        		 이러한 테마를 활용하여 예래생태마을 해변축제를 개최하고 있습니다.
          	</span>
          </div> 
        </div>
        
         <div class="row">
           <div class="col m2">
          <span class="natural"><img src="../../common/images/natural26.jpg" width="100%" alt="서귀포 칠십리 축제"/> </span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">서귀포 칠십리 축제</p>
          	<span class="natural-s2">
        		 서귀포칠십리축제는 1995년부터 매년 9~10월경 서귀포에서 열리고 있습니다. 2003년 제주도에서 유일하게 문화체육관광부 예비축제로 선정되었으며, 2007년에는 2년 연속 유망축제로 승급되었습니다. 이 축제는 서귀포 칠십리 해안 일대에서 제주의 정취를 느낄 수 있도록 해양체험, 민속체험 등 다채로운 프로그램으로 진행됩니다. 서귀포의 삶의 터전인 칠십리의 탄생과 저력, 섬으로서의 아름다움과 신비감, 그 속에서 나누었던 이야기와 그들이 품었던 꿈과 사랑, 이 모두를 형상화시켜 표현하는 것이 서귀포칠십리축제 입니다. 이 축제는 다양한 주제를 갖고 축제 참가자 모두가 즐거운 마음으로 참여할 수 있도록 프로그램과 공간배치를 테마화 함으로써 시민과 관광객 모두가 축제의 주인공이 될 수 있습니다.
          	</span>
          </div> 
        </div>


	  </div>
	</div>
	
		<? include_once "../../common/inc/inc_footer.php" ?>

  </body>
</html>
