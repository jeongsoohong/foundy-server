<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>
  <script  src="http://code.jquery.com/jquery-latest.min.js"></script>
  <? include_once "../../common/inc/inc_header.php" ?>
</head>
<body>
  <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">Natural Resources</h6>
          <h4 class="center white-text">색달동 자원</h4>
        </div>
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background6.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">
         
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<li class="col s3 th2"><a href="natural_01.php" target="_self" class="link_6th" >자연자원</a></li>
				<li class="col s3 th2"><a href="natural_02.php" target="_self" class="link_6th link_6th_ov" >역사문화자원</a></li>	
				<li class="col s3 th2"><a href="natural_03.php" target="_self" class="link_6th" >사설관광자원</a></li>	
				<li class="col s3 th2"><a href="natural_04.php" target="_self" class="link_6th" >지역축제</a></li>					
			</ul>
		</div>
	</div>
   
    <div class="section">

     <div id="responsive" class="section scrollspy">
        <div class="con_title center">역사문화자원</div>
        
       <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural9.jpg" width="100%" alt="본당"/> </span>
          	
          </div>
          
          <div class="col m9 mb30">
          <p class="natural-s1">본당</p>
          <span class="natural-s2">본향당에는 음력으로 정월 초하루와 8월 15일 추석날, 마을 부녀자들은 제물을 차려서 제단에 올리고 당을 맡고 있는 신방이 굿을 하고 마을의 안녕과 각 가정의 행운을 기원하고, 신방은 각가정에 1년간의 운수점을 보아주고 있습니다.
          	</span>
          </div>
        </div>
       <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural10.jpg" width="100%" alt="베락돌"/> </span>
          	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">베락돌</p>
          	<span class="natural-s2">
          	큰 암석 7개가 쌓인 곳이며, 아래 4개, 위 1개, 가운데 2개로 모두 3단으로 쌓여져 있습니다.<br/>
          	"베락돌"이란 이름은 이 돌에 벼락이 맞았다 하여 부르게 되었습니다. 
          	</span>
          </div>
        </div>
        
       <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural11.jpg" width="100%" alt="지석묘1호"/> </span>
          	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">지석묘1호</p>
          	<span class="natural-s2">
          	이 고인돌은 멀리서 보면 받침대 위에 놓인 거대한 수석 작품 같고 덮개돌로 쓴 바위 자체의 모습도 멋진데다 주변 정리는 잘 되어 있습니다.<br/>
          	전형적인 남방식 지석묘로 덮개돌 앞쪽에 이중으로 받침돌을 고인 돌림형 고인돌 입니다.
          	</span>
          </div>
        </div>
        
       <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural12.jpg" width="100%" alt="삿중하잣성"/></span> 
          	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">삿중하잣성</p>
          	<span class="natural-s2">
          	조선시대에 제주지역의 중산간 목초지에 만들어진 목장 경계용 돌담입니다. <br/>목장이 해안 평야 지대를 비롯한 섬 전역에 흩어져 있어 농작물에 피해를 주므로 한라산 중턱으로 목장을 옮기고 경계에 돌담을 쌓아 올렸습니다.
          	</span>
          </div>
        </div>
        
       <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural13.png" width="100%" alt="유물산포지"/> </span>
          	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">유물산포지</p>
          	<span class="natural-s2">
          	유적의 범위는 대략 2,000평이고 적갈색 결질 토기가 출토 되었습니다. <br/>색달천 주변 유적과 색달천 서쪽에 있는 예래천 하류의 예래동 유적을 중심으로 한 마을유적과 관련이 깊은 곳으로 제주도 남서부 일대의 중요한 유적이 될 것 입니다.
          	</span>
          </div>
        </div>
        
       <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural14.jpg" width="100%" alt="동굴입구 집자리"/></span> 
          	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">동굴입구 집자리</p>
          	<span class="natural-s2">
          	해수면에서 약 35m 정도 위에 ‘다람쥐궤’라고 불리는 해식동굴안에 형성되어 있습니다. <br/>이 동굴은 현재 해안선에 위치하는 해식동굴보다 형성시기가 이른 것으로 보입니다. <br/>굴의 막히는 부분까지는 약 20m 정도로 추정됩니다.
          	</span>
          </div>
        </div>
        
       <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural15.jpg" width="100%" alt="천제연 마애명"/></span> 
          	
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">천제연 마애명</p>
          	<span class="natural-s2">
          	1767년(영조 43)에 서귀포시 안덕면 창천리에 유배를 왔던 임관주가 유배에서 풀려 돌아가기 전 제주의 명승지를 유람할 적에 천제연에 들려 천제연의 풍광과 1단 폭포 못가에서 행해지던 활쏘기의 광경를 7언 절구로 지어 새겼습니다.<br/> 마애명이 새겨진 벼량의 암질이 단단하여 풍화에 의한 마모가 심하지 않아, 새겨진 지 250년 가까이 시간이 경과했지만 대부분의 글자가 육안으로 판독 가능합니다. 
          	</span>
          </div>
        </div>
        

 

	  </div>
	</div>
	
		<? include_once "../../common/inc/inc_footer.php" ?>

  </body>
</html>
