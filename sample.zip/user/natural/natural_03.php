<!DOCTYPE html>
<html lang="ko">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>중문색달마을</title>
  <script  src="http://code.jquery.com/jquery-latest.min.js"></script>
  <? include_once "../../common/inc/inc_header.php" ?>
</head>
<body>
  <? include_once "../../common/inc/inc_nav.php" ?>
  
  <div id="index-banner" class="parallax-container">
    <div class="section no-pad-bot">
      <div class="container">
        <div class="row center">
          <h6 class="col s12 mb30">Natural Resources</h6>
          <h4 class="center white-text">색달동 자원</h4>
        </div>
      </div>
      
    </div>
    
    <div class="parallax"><img src="../../common/images/background6.jpg" alt="Unsplashed background img 1"></div>
  
  </div>

  <div class="container">
   
   <div id="lnb" class="row">
         
		<div id="lnbwrap" class="wrapper">
			<ul class="lm_2th">	
				<li class="col s3 th2"><a href="natural_01.php" target="_self" class="link_6th" >자연자원</a></li>
				<li class="col s3 th2"><a href="natural_02.php" target="_self" class="link_6th" >역사문화자원</a></li>	
				<li class="col s3 th2"><a href="natural_03.php" target="_self" class="link_6th link_6th_ov" >사설관광자원</a></li>	
				<li class="col s3 th2"><a href="natural_04.php" target="_self" class="link_6th" >지역축제</a></li>					
			</ul>
		</div>
	</div>
   
    <div class="section">

     <div id="responsive" class="section scrollspy">
        <div class="con_title center">사설관광자원</div>
        
    	 <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural16.jpg" width="100%" alt="퍼시픽랜드"/></span> 
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">퍼시픽랜드</p>
          	<span class="natural-s2">
          	중문관광단지 내에 있는 퍼시픽랜드는 귀여운 돌고래의 재롱에 연신 박수를 보내게 되는 곳으로 남녀노소가 함께 즐길 수 있는 패밀리 레저 타운입니다.  <br/>돌고래 이외에도 바다 사자의 깜찍스러운 묘기와 펭귄의 재롱을 아울러 볼 수 있습니다.   <br/>
          	또한 전세계의 어종을 볼 수 있고, 해양 상태를 보고 배울 수 있는 거대한 해양 수족관이 들어서 있습니다.
          	</span>
          </div>         
         
        </div>
         <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural17.gif" width="100%" alt="제주여미지식물원"/></span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">제주여미지식물원</p>
          	<span class="natural-s2">
          	  중문관광단지 내에 있는 여미지 식물원에는 온실 내에 2천여 종의 온갖 식물이 있으며, 온실 밖에는 1천 7백여 종의 나무와 화초류가 심어져 있습니다.  한국식 정원을 비롯하여 일본, 이태리, 불란서 양식등 민속 정원도 꾸며 놓아 세계의 정원 형태를 한 눈에 볼 수 있도록 했습니다.  온실과 정원 사이에는 60인승 관광 유람 열차가 운행 되며 온실 중앙의 전망탑은 높이가 38m로 날씨가 좋은 날은 멀리 국토 최남단인 마라도까지 볼 수 있습니다.
          	</span>
          </div>
        </div>
         <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural18.jpg" width="100%" alt="테디베어뮤지엄"/></span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">테디베어뮤지엄</p>
          	<span class="natural-s2">
          	  세계적인 휴양관광명소인 중문관광단지에 국내 최초로 개장된 테디베어 뮤지엄(Teddy Bear Museum). 테디베어는 100여년전 독일과 미국에서 탄생한 후 전세계 어린이와 연인들의 영원한 벗이 되어준 봉제인형입니다. 뮤지엄에 오면 세계 각국의 진귀한 테디베어와 20세기 인류의 역사 및 흥미로운 주제를 테디베어로 표현한 갤러리, 테디베어 케릭터 샵(Shop), 퓨전요리의 진수를 느낄 수 있는 레스토랑, 그리고 넓은 야외공원에서 색다른 추억을 만들 수 있습니다. 테디베어뮤지엄은 가족과 연인끼리 즐거운 시간을 보낼 수 있는 새로운 관광명소로 국내외 여행자들의 발길을 붙들고 있습니다.
          	</span>
          </div>
        </div>
         <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural19.jpg" width="100%" alt="믿거나말거나 박물관"/></span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">믿거나말거나 박물관</p>
          	<span class="natural-s2">
          	 '리플리의 믿거나 말거나(Ripley's Believe It or Not!)'는 신문 만화가 출신의 모험가 로버트 리플리가 지구를 18바퀴나  돌 정도로 전세계 198개국을 누비면서 가능한 모든 부문에서 수집한 기묘한 사실들의 방대한 기록과 컬렉션 입니다. 그의 만화 '리플리의 믿거나 말거나'가 큰 인기를 끌면서 조금씩 영역을 넓혀 세상의 모든 진기한 기록들을 수집하였으며 1941년 로버트 리플리의 사후 후배와 친구들은 리플리 재단을 설립. 책의 발간과 박물관 건립을 이어 가고 있습니다. 이후 '리플리의 믿거나 말거나(Ripley's Believe It or Not!)'는 특이한 소재를 발굴하여 소개하는 프랜차이즈 매체로 라디오, 텔레비전, 박물관, 책 등 다양한 매체로 만들어졌고 박물관은 미국, 캐나다, 영국, 멕시코, 덴마크, 오스트레일리아 등 전세계 여러 곳에 세워져 있으며 세계 최대의 엔터테인먼트 박물관 체인으로 성장 하였습니다. '믿거나 말거나 박물관 제주'는 전세계 11번째 리플리 유치국이며 32번째 '믿거나 말거나 박물관'으로 최고의 관광지 제주 중문단지에서 2010년 12월 24일 오픈 하였습니다.
          	</span>
          </div>
        </div>
         <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural20.jpg" width="100%" alt="박물관은 살아있다."/> </span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">박물관은 살아있다</p>
          	<span class="natural-s2">
          	  문화놀이 공간 <박물관은 살아있다> 는 국내 최초로 옵티컬 일루전 아트를 도입하여, 바라만 봐야했던 미술관을 보고, 듣고, 만질 수 있는 체험형 박물관으로 승화시킨 문화 콘텐츠 공간입니다. [박물관은 살아있다] 제주 중문점은 세계최대착시테마파크로 매일같이 변화하는 박물관, 갈 때마다 변화하고 있는 박물관, 즐거운 박물관을 지향합니다. 상상이 현실로 다가오는 체험은 착시아트, 미디어아트, 오브제아트, 스컬쳐아트, 프로방스아트 등 5가지 테마로 이루어져 있으며, 내가 주인공이 되어 직접 보고, 듣고, 만지고, 참여하여 현장에서의 신기한 체험을 SNS에 남김으로써 즐거움이 배가 되는 Fun오감만족 체험박물관입니다. 세계적 관광휴양지인 제주도 중문관광단지 입구에 위치하고 있으며, 약 1만 평의 대지에 쾌적하고 넓은 실내전시관과 아름다운 야외정원, 드넓은 주차시설을 갖춘 제주도의 대표관광지로 접근성의 용이함과 풍부한 컨텐츠는 제주여행의 필수코스로 자리매김하여 많은 관심과 사랑을 받고 있습니다.
          	</span>
          </div>
        </div>
         <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural21.jpg" width="100%" alt="플레이 케이팝 박물관"/> </span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">플레이 케이팝 박물관</p>
          	<span class="natural-s2">
          	세계적인 한류 스타 싸이와 <강남 스타일> 춤을 추고, 지드래곤과 카페에 앉아 달콤한 시간을 보내고, 산다라 박과 함께 멋진 밴을 타고 여행을 떠나보자!<br/> 제주 중문관광단지 안에 문을 연 ‘플레이 케이팝’은 세계 최대의 K-POP 뮤지엄을 표방한 미래형 디지털 테마파크 입니다. <br/>
          	다양한 체험시설을 통해 한류 스타들과 실감나는 데이트를 즐길 수 있습니다.  제주에서, 한류 스타와 꿈같은 데이트를 즐겨보시려면 플레이 케이팝 박물관을 방문하세요.
          	</span>
          </div>
        </div>
         <div class="row">
          <div class="col m2">
          <span class="natural"><img src="../../common/images/natural22.jpg" width="100%" alt="제주다원"/></span>
          </div>
          <div class="col m9 mb30">
          	<p class="natural-s1">제주다원</p>
          	<span class="natural-s2">
          	서귀포 색달동에 위치한 제주다원은, 녹차미로공원을 비롯하여 해발 500m에 위치한 제주 최고의 전망을 자랑하는 전망대찻집에서 여유를 즐겨보는 것도 좋을 것입니다.<br/>하늘과 바다가 맞닿은 지상 최고의 전망대찻집에서 가마솥덖음수제차 즐기기, 녹차아이스크림, 녹차쿠키, 녹차와플 등을 시음할 수 있습니다.
          	</span>
          </div>
        </div>
        
 

	  </div>
	</div>
	
		<? include_once "../../common/inc/inc_footer.php" ?>

  </body>
</html>
